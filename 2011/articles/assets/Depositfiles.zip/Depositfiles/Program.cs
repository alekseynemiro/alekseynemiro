﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Diagnostics;

namespace Depositfiles
{
  class Program
  {
    [STAThreadAttribute]
    static void Main(string[] args)
    {
      Console.WriteLine("Пример к статье");
      Console.WriteLine("<Загрузка файлов на сайт по протоколу HTTP на примере depositfiles.com>");
      Console.WriteLine("Автор: Алексей Немиро");
      Console.WriteLine("http://aleksey.nemiro.ru");
      Console.WriteLine("http://kbyte.ru");
      Console.WriteLine("01.08.2011");
      Console.WriteLine("---------------------------------------------------------------------------");

      // 1. Запрос сервера для загрузки файла
      Console.WriteLine("Запрос сервера для загрузки файла.");

      /*
      HttpWebRequest myReq = (HttpWebRequest)HttpWebRequest.Create("http://depositfiles.com/api/get_upload_info.php");
      HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
      StreamReader myStream = new StreamReader(myResp.GetResponseStream(), Encoding.UTF8);
      string html = myStream.ReadToEnd();
      */

      XmlDocument myXml = new XmlDocument();
      myXml.Load("http://depositfiles.com/api/get_upload_info.php");

      Console.WriteLine("Максимально допустимый размер файла для загрузки: {0} Mb", myXml.SelectSingleNode("result/max_file_size").InnerText);
      Console.WriteLine("Ссылка для загрузки файла в обменник:");
      Console.WriteLine(myXml.SelectSingleNode("result/http_upload_path").InnerText);
      string uploadUrl = myXml.SelectSingleNode("result/http_upload_path").InnerText;

      // выбор файла для отправки в обменник
      Console.WriteLine("Выберите файл для отправки в обменник.");
      OpenFileDialog ofd = new OpenFileDialog();
      if (ofd.ShowDialog() == DialogResult.Cancel)
      {
        Console.WriteLine("Файл не выбран.");
        Console.WriteLine("Нажмите любую клавишу, чтобы завершить работу программы.");
        Console.ReadKey();
        return;
      }

      // пытаемся определить тип содержимого по расширению файла
      string uploadFileContentType = "application/octet-stream"; // по умолчанию будет application/octet-stream
      Microsoft.Win32.RegistryKey myRegistryKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(Path.GetExtension(ofd.FileName));
      if (myRegistryKey != null && myRegistryKey.GetValue("Content Type") != null)
      {
        uploadFileContentType = myRegistryKey.GetValue("Content Type").ToString();
      }

      Console.WriteLine("Выбран файл: {0}", Path.GetFileName(ofd.FileName));
      Console.WriteLine("Тип содержимого: {0}", uploadFileContentType);

      // 2. Отправка файла в обменник
      Console.WriteLine("Отправка файла в обменник.");
      // создаем границу
      string boundary = "----------" + DateTime.Now.Ticks.ToString("x");

      HttpWebRequest myReq = (HttpWebRequest)HttpWebRequest.Create(uploadUrl);
      myReq.Method = "POST";
      // ВАЖНО: тип контента должен быть multipart/form-data
      // а также нужно обязательно указать метку границы
      myReq.ContentType = String.Format("multipart/form-data; boundary={0}", boundary);

      // добавляем параметры
      using (Stream myReqStream = myReq.GetRequestStream())
      {
        // добавляем параметры
        // в данном случае всего один тектовой параметр с именем format,
        // который указывает, в каком формате сервер должен отвечать
        string header = String.Format("\r\n--{0}\r\nContent-Disposition: form-data; name=\"{1}\"\r\n\r\n", boundary, "format");
        byte[] h = System.Text.Encoding.UTF8.GetBytes(header);
        myReqStream.Write(h, 0, h.Length); // пишем заголовок
        // пишем значение параметра, в данном случае - xml
        byte[] b = System.Text.Encoding.UTF8.GetBytes("xml");
        myReqStream.Write(b, 0, b.Length); 

        // добавляем файл
        // name - это имя параметра - поля выбора файлов на ПК юзера:
        // <input size="51" name="files" class="file" type="file">
        // в данном случае - files, но на других сайтах имя может быть другим
        header = String.Format("\r\n--{0}\r\nContent-Disposition: form-data; name=\"{1}\"; filename=\"{2}\"\r\nContent-Type: {3}\r\n\r\n", boundary, "files", Path.GetFileName(ofd.FileName), uploadFileContentType);
        h = System.Text.Encoding.UTF8.GetBytes(header);
        myReqStream.Write(h, 0, h.Length); // пишем заголовок
        // пишем тело выбранного файла в запрос
        using (FileStream myFile = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read))
        {
          using (BinaryReader myReader = new BinaryReader(myFile))
          {
            byte[] buffer = myReader.ReadBytes(2048);
            while (buffer.Length > 0)
            {
              myReqStream.Write(buffer, 0, buffer.Length);
              buffer = myReader.ReadBytes(2048);
            }
          }
        }

        // подвал
        string footer = String.Format("\r\n--{0}--\r\n", boundary);
        byte[] f = System.Text.Encoding.UTF8.GetBytes(footer);
        myReqStream.Write(f, 0, f.Length);
      }

      // получаем ответ от сервера
      HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
      StreamReader myStream = new StreamReader(myResp.GetResponseStream(), Encoding.UTF8);
      string str = myStream.ReadToEnd();
      myXml.LoadXml(str);

      // выводим
      Console.WriteLine("");
      Console.WriteLine("Ссылка на файл:");
      Console.WriteLine(myXml.SelectSingleNode("result/download_url").InnerText);
      Console.WriteLine("Ссылка для удаления файла:");
      Console.WriteLine(myXml.SelectSingleNode("result/delete_url").InnerText);
      Console.WriteLine("");
      Console.WriteLine("Хотите открыть ссылку на загруженный файл?");
      Console.WriteLine("y - да, n - неа");
      ConsoleKeyInfo k = Console.ReadKey(true);
      while (k.Key != ConsoleKey.Y && k.Key != ConsoleKey.N)
      {
        Console.WriteLine("Нужно нажать на клавишу:");
        Console.WriteLine("y - да, n - неа");
        Console.WriteLine("А вопрос я повторять не буду! :P");
        k = Console.ReadKey(true);
      }
      if (k.Key == ConsoleKey.Y)
      {
        Process.Start(myXml.SelectSingleNode("result/download_url").InnerText);
      }

      Console.WriteLine("");
      Console.WriteLine("Нажмите любую клавишу, чтобы выйти из программы.");
      Console.ReadKey();
      return;
    }
  }
}
