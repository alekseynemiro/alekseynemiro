﻿'***********************************************************
'Пример к статье «Разработка прокси-сервера»
'http://kbyte.ru/ru/Programming/Articles.aspx?id=66&mode=art
'Автор: Алексей Немиро
'http://aleksey.nemiro.ru
'Специально для Kbyte.Ru
'http://kbyte.ru
'Copyright © Aleksey S Nemiro, 2011
'***********************************************************

Imports System.Net.Sockets
Imports System.Net
Imports System.IO
Imports System.Text.RegularExpressions

Module Module1

  Sub Main()
    'слушаем локальный апишник (127.0.0.1) и порт 8888
    Dim myTcp As New TcpListener(IPAddress.Parse("127.0.0.1"), 8888)

    'поехали!
    myTcp.Start()

    Do

      ' смотрим, есть запрос или нет
      If myTcp.Pending() Then

        'запрос есть
        Using myClient As Socket = myTcp.AcceptSocket()

          'соединяемся
          If myClient.Connected Then

            'получаем тело запроса
            Dim httpRequest() As Byte = ReadToEnd(myClient)

            'ищем хост и порт
            Dim myReg As New Regex("Host: (((?<host>.+?):(?<port>\d+?))|(?<host>.+?))\s+", RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            Dim m As Match = myReg.Match(System.Text.Encoding.ASCII.GetString(httpRequest))
            Dim host As String = m.Groups("host").Value
            Dim port As Integer = 0
            'если порта нет, то используем 80 по умолчанию
            If Not Integer.TryParse(m.Groups("port").Value, port) Then port = 80

            If String.IsNullOrEmpty(host) Then
              'хост не найден
              Console.WriteLine("Хост не найден.")
            Else '// If String.IsNullOrEmpty(host) Then

              'получаем апишник по хосту
              Dim myIPHostEntry As IPHostEntry = Dns.GetHostEntry(host)

              'создаем точку доступа
              Dim myIPEndPoint As New IPEndPoint(myIPHostEntry.AddressList(0), port)

              'создаем сокет и передаем ему запрос
              Using myRerouting As New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                myRerouting.Connect(myIPEndPoint)
                If Not myRerouting.Send(httpRequest, httpRequest.Length, SocketFlags.None) = httpRequest.Length Then
                  Console.WriteLine("При отправке данных удаленному серверу произошла ошибка...")
                Else
                  'получаем ответ
                  Dim httpResponse() As Byte = ReadToEnd(myRerouting)
                  'передаем ответ обратно клиенту
                  If httpResponse IsNot Nothing AndAlso httpResponse.Length > 0 Then
                    myClient.Send(httpResponse, httpResponse.Length, SocketFlags.None)
                  End If
                End If
              End Using

            End If '// If String.IsNullOrEmpty(host) Then


          End If '// If myClient.Connected Then

        End Using

      End If

    Loop

    myTcp.Stop()

  End Sub

  Private Function ReadToEnd(mySocket As Socket) As Byte()
    Dim b(mySocket.ReceiveBufferSize) As Byte
    Dim len As Integer = 0
    Using m As New MemoryStream
      len = mySocket.Receive(b, mySocket.ReceiveBufferSize, SocketFlags.None)
      Do While len > 0
        m.Write(b, 0, len)
        If Not mySocket.Poll(1000000, SelectMode.SelectRead) Then Exit Do
        len = mySocket.Receive(b, mySocket.ReceiveBufferSize, SocketFlags.None)
      Loop
      Return m.ToArray()
    End Using
  End Function

End Module
