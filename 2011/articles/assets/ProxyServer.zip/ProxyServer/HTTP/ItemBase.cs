﻿/*
 * Пример к статье «Разработка прокси-сервера»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=66&mode=art
 * Автор: Алексей Немиро
 * http://aleksey.nemiro.ru
 * Специально для Kbyte.Ru
 * http://kbyte.ru
 * Copyright © Aleksey S Nemiro, 2011
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProxyServer.HTTP
{
  public class  ItemBase
  {

    private string _Source = String.Empty;

    public string Source
    {
      get
      {
        return _Source;
      }
    }

    public ItemBase(string source)
    {
      _Source = source;
    }

  }
}
