﻿/*
 * Пример к статье «Разработка прокси-сервера»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=66&mode=art
 * Автор: Алексей Немиро
 * http://aleksey.nemiro.ru
 * Специально для Kbyte.Ru
 * http://kbyte.ru
 * Copyright © Aleksey S Nemiro, 2011
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections;
using System.Threading;

namespace ProxyServer
{
  class Program
  {

    private static string _ProxyAddress = "127.0.0.1"; // хост или айпи-адрес
    private static int _ProxyPort = 8888; // порт

    private static bool _NeedAuth = false; // требуется авторизация или нет
    private static string _Login = "test"; // имя пользователя для доступа к прокси-серверу
    private static string _Password = "123123"; // пароль для доступа к прокси-серверу
 
    private static bool _AppendHtml = true; // если true, то в html-ответы клиенту будет добавлять дополнительный код
    
    private static bool _AllowBlackList = true; // использовать черный список для ограничения доступа к сайтам
    private static string[] _BlackList = null; // список запрещенных доменов

    static void Main(string[] args)
    {
      WriteLog("Пример к статье «Разработка прокси-сервера»");
      WriteLog("http://kbyte.ru/ru/Programming/Articles.aspx?id=66&mode=art");
      WriteLog("Автор: Алексей Немиро");
      WriteLog("12 сентября 2011");
      WriteLog("-----------------------------------------------------------");
      WriteLog("Запуск сервера.");

      // грузим список запрещенных доменных имен
      if (_AllowBlackList && File.Exists("BlackList.txt")) _BlackList = File.ReadAllLines("BlackList.txt");
      // --

      TcpListener myTCP = new TcpListener(IPAddress.Parse(_ProxyAddress), _ProxyPort);

      myTCP.Start();

      WriteLog("Прокси-сервер успешно запущен, ожидаение запросов на адрес {0} порт {1}.", _ProxyAddress, _ProxyPort);
      while (true)
      {
        // ждем запросы от клиента
        if (myTCP.Pending())
        {
          // создаем поток
          Thread t = new Thread(ExecuteRequest);
          t.IsBackground = true;
          t.Start(myTCP.AcceptSocket());
        }
      }

      myTCP.Stop();
      
    }

    private static void ExecuteRequest(object arg)
    {
      try
      {

        // запрос есть, пытаемся установить соединение
        using (Socket myClient = (Socket)arg)
        {
          if (myClient.Connected)
          {
            // соединение установлено, получаем содержимое запроса
            byte[] httpRequest = ReadToEnd(myClient);

            // запрос получен, парсим
            HTTP.Parser http = new HTTP.Parser(httpRequest);

            // если заголовки не найдены, значит выполнить запрос не получится
            if (http.Items == null || http.Items.Count <= 0 || !http.Items.ContainsKey("Host"))
            {
              WriteLog("Получен запрос {0} байт, заголовки не найдены.", httpRequest.Length);
            }
            else
            {
              // заголовки найдены, можно продолжать выполнение запроса
              WriteLog("Получен запрос {0} байт, метод {1}, хост {2}:{3}", httpRequest.Length, http.Method, http.Host, http.Port);
              // WriteLog(http.GetHeadersAsString());

              // кстати: зная домен (http.Host), может вести учет посещения доменов,
              // а зная объем полученных от клиента данных (httpRequest.Length), можно вести учет исходящего трафика

              byte[] response = null; // в этой переменной будет ответ клиенту

              // если доступ к прокси-серверу ограничен, проверяем логин и пароль
              if (_NeedAuth)
              {
                if (!http.Items.ContainsKey("Authorization"))
                {
                  // логин и пароль не указан
                  response = GetHTTPError(401, "Unauthorized");
                  myClient.Send(response, response.Length, SocketFlags.None);
                  return;
                }
                else
                {
                  // указан логин и пароль, проверяем
                  string auth = Encoding.UTF8.GetString(Convert.FromBase64String(http.Items["Authorization"].Source.Replace("Basic ", "")));
                  string login = auth.Split(":".ToCharArray())[0];
                  string pwd = auth.Split(":".ToCharArray())[1];
                  if (_Login != login || _Password != pwd)
                  {
                    // неверный логин или пароль, возвращаем ошибку
                    response = GetHTTPError(401, "Unauthorized");
                    myClient.Send(response, response.Length, SocketFlags.None);
                    return;
                  }
                }
              }

              // проверка домена в черном списке
              if (_AllowBlackList && _BlackList != null && Array.IndexOf(_BlackList, http.Host.ToLower()) != -1)
              {
                // отправляем ответ клиенту
                response = GetHTTPError(403, "Forbidden");
                myClient.Send(response, response.Length, SocketFlags.None);
                return;
              }
              // --

              // определям апишник по хосту
              IPHostEntry myIPHostEntry = Dns.GetHostEntry(http.Host);

              if (myIPHostEntry == null || myIPHostEntry.AddressList == null || myIPHostEntry.AddressList.Length <= 0)
              {
                WriteLog("Не удалось определить IP-адрес по хосту {0}.", http.Host);
              }
              else
              {
                // создаем точку доступа
                IPEndPoint myIPEndPoint = new IPEndPoint(myIPHostEntry.AddressList[0], http.Port);
                
                // если запрос идет к защищенному ресурсу, 
                if (http.Method == HTTP.Parser.MethodsList.CONNECT)
                {
                  // возвращаем клиенту ошибку
                  // т.к. этот прокси-сервер не поддерживает работу с защищенными соединениями
                  WriteLog("Протокол HTTPS не реализован.");
                  response = GetHTTPError(501, "Not Implemented");
                } // HTTP.Parser.MethodsList.CONNECT
                else
                { // обычный запрос

                  // перенаправляем запрос на указанный хост
                  using (Socket myRerouting = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
                  {
                    myRerouting.Connect(myIPEndPoint);
                    if (myRerouting.Send(httpRequest, httpRequest.Length, SocketFlags.None) != httpRequest.Length)
                    {
                      WriteLog("Данные хосту {0} не были отправлены...", http.Host);
                    }
                    else
                    {
                      // получаем ответ
                      HTTP.Parser httpResponse = new HTTP.Parser(ReadToEnd(myRerouting));
                      if (httpResponse.Source != null && httpResponse.Source.Length > 0)
                      {
                        WriteLog("Получен ответ {0} байт, код состояния {1}", httpResponse.Source.Length, httpResponse.StatusCode);
                        // WriteLog(httpResponse.GetHeadersAsString());

                        // кстати: зная размер полученных данных (httpResponse.Source.Length), можно вести учет входящего трафика

                        response = httpResponse.Source;

                        // анализ ответа удаленного сервера и подготовка данных для отправки клиенту
                        switch (httpResponse.StatusCode)
                        {
                          // количество страниц для разных типов ошибок можно увеличить,
                          // я сделал фильтр лишь для наиболее популярных ошибок
                          case 400:
                          case 403:
                          case 404:
                          case 407:
                          case 500:
                          case 501:
                          case 502:
                          case 503:
                            response = GetHTTPError(httpResponse.StatusCode, httpResponse.StatusMessage);
                            break;

                          default:
                            // здесь можно внести изменения html, который будет возвращаен клиенту
                            if (_AppendHtml)
                            {
                              // необходимо проверить, html это или нет
                              if (httpResponse.Items.ContainsKey("Content-Type") && ((HTTP.ItemContentType)httpResponse.Items["Content-Type"]).Value == "text/html")
                              {
                                // если это html, то берем тело
                                string body = httpResponse.GetBodyAsString();

                                // добавляем наш текст в нужно место.
                                // в этом примере я изменю заголовок страницы - теги title
                                body = Regex.Replace(body, "<title>(?<title>.*?)</title>", "<title>ProxyServer - $1</title>");

                                // и в шапку содержимого (сразу после тега body) страницы добавлю div
                                body = Regex.Replace(body, "(<body.*?>)", "$1<div style='height:20px;width:100%;background-color:black;color:white;font-weight:bold;text-align:center;'>Example of Proxy Server by Aleksey Nemiro</div>");

                                // вставляем содержимое обратно
                                httpResponse.SetStringBody(body);

                                // беерем новое содержимое из источника (см. код функции SetStringBody)
                                response = httpResponse.Source;
                              }
                            }
                            // собственно, можно и графические файлы подменять и любые другие типы данных
                            break;
                        }

                      }
                      else
                      {
                        WriteLog("Получен ответ 0 байт");
                      }

                    }
                    myRerouting.Close();
                  }
                } // HTTP.Parser.MethodsList.CONNECT

                // отправляем ответ клиенту
                if (response != null) myClient.Send(response, response.Length, SocketFlags.None);
              }
            }

            // закрываем соединение
            myClient.Close();
          }
        }
      }
      catch (Exception ex)
      {
        WriteLog("Ошибка: ", ex.Message);
      }
    }

    private static byte[] ReadToEnd(Socket mySocket)
    {
      byte[] b = new byte[mySocket.ReceiveBufferSize];
      int len = 0;
      using (MemoryStream m = new MemoryStream())
      {
        while (mySocket.Poll(1000000, SelectMode.SelectRead) && (len=mySocket.Receive(b, mySocket.ReceiveBufferSize, SocketFlags.None)) > 0)
        {
          m.Write(b, 0, len);
        }
        return m.ToArray();
      }
    }

    /// <summary>
    /// Функция возвращает измененную страницу с информацией об ошибке
    /// </summary>
    private static byte[] GetHTTPError(int statusCode, string statusMessage)
    {
      FileInfo FI = new FileInfo(String.Format("HTTP{0}.htm", statusCode));
      // создаем HTTP-заголовки, в соответствии со стандартами
      byte[] headers = Encoding.ASCII.GetBytes(String.Format("HTTP/1.1 {0} {1}\r\n{3}Content-Type: text/html\r\nContent-Length: {2}\r\n\r\n", statusCode, statusMessage, FI.Length, (statusCode == 401 ? "WWW-Authenticate: Basic realm=\"ProxyServer Example\"\r\n" : "")));
      byte[] result = null;

      // страницы с информацией об ошибках хранятся в html-файлах с именем HTTP[код ошибки].htm
      using (FileStream fs = new FileStream(FI.FullName, FileMode.Open, FileAccess.Read))
      {
        using (BinaryReader br = new BinaryReader(fs, Encoding.UTF8))
        {
          // добавляем к заголовкам содержимое файла
          result = new byte[headers.Length + fs.Length];
          Buffer.BlockCopy(headers, 0, result, 0, headers.Length);
          Buffer.BlockCopy(br.ReadBytes(Convert.ToInt32(fs.Length)), 0, result, headers.Length, Convert.ToInt32(fs.Length));
        }
      }

      // возвращаем результат
      return result;
    }

    /// <summary>
    /// Метод добавляет запись в отчет
    /// </summary>
    /// <param name="msg">Сообщение</param>
    /// <param name="args">Дополенительные параметры</param>
    private static void WriteLog(string msg, params object[] args)
    {
      Console.WriteLine(DateTime.Now.ToString() + " : " + msg, args);
    }

  }
}
