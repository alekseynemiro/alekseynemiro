﻿/*
 * Пример к статье «Разработка прокси-сервера»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=66&mode=art
 * Автор: Алексей Немиро
 * http://aleksey.nemiro.ru
 * Специально для Kbyte.Ru
 * http://kbyte.ru
 * Copyright © Aleksey S Nemiro, 2011
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;

namespace ProxyEasyWithThreads
{
  class Program
  {
    static void Main(string[] args)
    {
      // слушаем локальный апишник (127.0.0.1) и порт 8888
      TcpListener myTCP = new TcpListener(IPAddress.Parse("127.0.0.1"), 8888);
      // поехали!
      myTCP.Start();

      while (true)
      {
        // смотрим, есть запрос или нет
        if (myTCP.Pending())
        {
          // запрос есть
          // передаем его в отдельный поток
          Thread t = new Thread(ExecuteRequest);
          t.IsBackground = true;
          t.Start(myTCP.AcceptSocket());
        }
      }

      myTCP.Stop();
    }

    private static void ExecuteRequest(object arg)
    {
      Socket myClient = (Socket)arg;
      // соединяемся
      if (myClient.Connected)
      {
        // получаем тело запроса
        byte[] httpRequest = ReadToEnd(myClient);
        // ищем хост и порт
        Regex myReg = new Regex(@"Host: (((?<host>.+?):(?<port>\d+?))|(?<host>.+?))\s+", RegexOptions.Multiline | RegexOptions.IgnoreCase);
        Match m = myReg.Match(System.Text.Encoding.ASCII.GetString(httpRequest));
        string host = m.Groups["host"].Value;
        int port = 0;
        // если порта нет, то используем 80 по умолчанию
        if (!int.TryParse(m.Groups["port"].Value, out port)) { port = 80; }

        // получаем апишник по хосту
        IPHostEntry myIPHostEntry = Dns.GetHostEntry(host);

        // создаем точку доступа
        IPEndPoint myIPEndPoint = new IPEndPoint(myIPHostEntry.AddressList[0], port);

        // создаем сокет и передаем ему запрос
        using (Socket myRerouting = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
        {
          myRerouting.Connect(myIPEndPoint);
          if (myRerouting.Send(httpRequest, httpRequest.Length, SocketFlags.None) != httpRequest.Length)
          {
            Console.WriteLine("При отправке данных удаленному серверу произошла ошибка...");
          }
          else
          {
            // получаем ответ
            byte[] httpResponse = ReadToEnd(myRerouting);
            // передаем ответ обратно клиенту
            if (httpResponse != null && httpResponse.Length > 0)
            {
              myClient.Send(httpResponse, httpResponse.Length, SocketFlags.None);
            }
          }
        }
        myClient.Close();
      }
    }

    private static byte[] ReadToEnd(Socket mySocket)
    {
      byte[] b = new byte[mySocket.ReceiveBufferSize];
      int len = 0;
      using (MemoryStream m = new MemoryStream())
      {
        while (mySocket.Poll(1000000, SelectMode.SelectRead) && (len = mySocket.Receive(b, mySocket.ReceiveBufferSize, SocketFlags.None)) > 0)
        {
          m.Write(b, 0, len);
        }
        return m.ToArray();
      }
    }

  }
}
