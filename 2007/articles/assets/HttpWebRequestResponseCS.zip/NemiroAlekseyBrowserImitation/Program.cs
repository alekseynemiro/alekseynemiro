﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;

namespace NemiroAlekseyBrowserImitation
{
  /// <summary>
  /// Пример прохождения процедуры авторизации на сайте Yandex.Ru
  /// Автор: Немиро Алексей, mailto:aleksey@kbyte.ru
  /// Copyright (c) Nemiro AS, 2007
  /// Специально для проекта Kbyte.Ru (http://kbyte.ru)
  /// </summary>
  class Program
  {
    static void Main(string[] args)
    {
      try
      {
        Console.WriteLine("Пример прохождения авторизации на сайте http://yandex.ru");
        Console.WriteLine("Автор: Немиро Алексей, mailto:aleksey@kbyte.ru");
        Console.WriteLine("Copyright (c) Nemiro AS, 2007");
        Console.WriteLine("Специально для проекта Kbyte.Ru (http://kbyte.ru)");
        Console.WriteLine("\r\nВведите логин: ");
        string sLogin = Console.ReadLine();
        Console.WriteLine("Введите пароль: ");
        string sPassword = Console.ReadLine();

        Console.WriteLine("Использовать прокси-сервер? (true/false)");
        bool bProxy = false;
        string sProxyAddress = "127.0.0.1"; int iProxyPort = 8888;
        bool.TryParse(Console.ReadLine(), out bProxy);
        if (bProxy)
        {
          Console.WriteLine("Укажите адрес (например, 127.0.0.1)");
          sProxyAddress = Console.ReadLine();
          Console.WriteLine("Укажите порт (например, 8888)");
          int.TryParse(Console.ReadLine(), out iProxyPort);
        }

        Console.WriteLine("\r\nLogin: " + sLogin);
        Console.WriteLine("Password: " + sPassword);
        Console.WriteLine("Proxy: " + (bProxy ? sProxyAddress + " @ " + iProxyPort.ToString() : "none"));
        Console.WriteLine("Выполяется авторизация, ждите..");

        HttpWebRequest myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create("http://yandex.ru");
        if (bProxy) { myHttpWebRequest.Proxy = new WebProxy(sProxyAddress, iProxyPort); }
        myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;";
        myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*";
        myHttpWebRequest.Headers.Add("Accept-Language", "ru");

        // запрос на http://yandex.ru
        HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();

        // получаем куки, которые возвратил http://yandex.ru
        string sCookies = "";
        if (!String.IsNullOrEmpty(myHttpWebResponse.Headers["Set-Cookie"]))
        {
          sCookies = myHttpWebResponse.Headers["Set-Cookie"];
        }

        // авторизация на yandex.ru
        myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create("http://passport.yandex.ru/passport?mode=auth");
        if (bProxy) { myHttpWebRequest.Proxy = new WebProxy(sProxyAddress, iProxyPort); }
        myHttpWebRequest.Method = "POST"; // метод POST
        myHttpWebRequest.Referer = "http://yandex.ru";
        myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;";
        myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*";
        myHttpWebRequest.Headers.Add("Accept-Language", "ru");
        myHttpWebRequest.ContentType = "application/x-www-form-urlencoded";

        // передаем куки, полученные в предыдущем запросе
        if (!String.IsNullOrEmpty(sCookies))
        {
          myHttpWebRequest.Headers.Add(HttpRequestHeader.Cookie, sCookies);
        }

        // ставим False, чтобы при получении кода 302 не делать автоматический редирект
        myHttpWebRequest.AllowAutoRedirect = false;

        // передаем параметры
        TimeSpan ts = DateTime.Now - new DateTime(1970, 1, 1);
        string sQueryString = "retpath=http%3A%2F%2Fmail.yandex.ru%2F&timestamp=" +
                              Math.Floor(ts.TotalSeconds).ToString() + 
                              "&login=" + sLogin + "&passwd=" + sPassword;
        byte[] ByteArr = System.Text.Encoding.GetEncoding(1251).GetBytes(sQueryString);
        myHttpWebRequest.ContentLength = ByteArr.Length;
        myHttpWebRequest.GetRequestStream().Write(ByteArr, 0, ByteArr.Length);

        // выполняем запрос
        myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();

        // найден новый url
        string sLocation = myHttpWebResponse.Headers["Location"];
        if (!String.IsNullOrEmpty(sLocation))
        {
          // получам куки
          sCookies = "";
          if (!String.IsNullOrEmpty(myHttpWebResponse.Headers["Set-Cookie"]))
          {
            sCookies = myHttpWebResponse.Headers["Set-Cookie"];
          }
          // формируем запрос
          myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create("http://passport.yandex.ru" + sLocation);
          if (bProxy) { myHttpWebRequest.Proxy = new WebProxy(sProxyAddress, iProxyPort); }
          myHttpWebRequest.Referer = "http://passport.yandex.ru/passport?mode=auth";
          myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;";
          myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*";
          myHttpWebRequest.Headers.Add("Accept-Language", "ru");
          myHttpWebRequest.ContentType = "text/plain";
          if (!String.IsNullOrEmpty(sCookies))
          {
            myHttpWebRequest.Headers.Add(HttpRequestHeader.Cookie, sCookies);
          }

          // выполняем запрос
          myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();

          // смотрим, делается ли редирект JavaScrip-ом
          if (new StreamReader(myHttpWebResponse.GetResponseStream(), Encoding.GetEncoding(1251)).ReadToEnd().IndexOf("window.location.replace") > 0)
          {
            // входим в сервис
            myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create("http://mail.yandex.ru/");
            if (bProxy) { myHttpWebRequest.Proxy = new WebProxy(sProxyAddress, iProxyPort); }
            myHttpWebRequest.Referer = "http://passport.yandex.ru" + sLocation;
            myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;";
            myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*";
            myHttpWebRequest.Headers.Add("Accept-Language", "ru");
            myHttpWebRequest.ContentType = "text/html; charset=windows-1251";
            if (!String.IsNullOrEmpty(sCookies))
            {
              myHttpWebRequest.Headers.Add(HttpRequestHeader.Cookie, sCookies);
            }
            // выполняем запрос
            myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
          }
          else
          {
            Console.WriteLine("Данные не найдены..\r\nНажмите любую клавишу для заврешения");
            Console.ReadKey();
            return;
          }
        }
        // выводим результат в консоль
        Console.WriteLine(new StreamReader(myHttpWebResponse.GetResponseStream(), Encoding.GetEncoding(1251)).ReadToEnd());
      }
      catch (Exception ex)
      {
        Console.WriteLine("Ошибка: " + ex.ToString());
      }

      Console.WriteLine("Нажмите любую клавишу для завершения.");
      Console.ReadKey();
    }
  }
}
