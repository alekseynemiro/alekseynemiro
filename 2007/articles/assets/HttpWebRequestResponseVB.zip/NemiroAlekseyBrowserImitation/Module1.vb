﻿Imports System.Net
Imports System.Text
Imports System.IO

''' <summary>
''' Пример прохождения процедуры авторизации на сайте Yandex.Ru
''' Автор: Немиро Алексей, mailto:aleksey@kbyte.ru
''' Copyright (c) Nemiro AS, 2007
''' Специально для проекта Kbyte.Ru (http://kbyte.ru)
''' </summary>
Module Module1

  Sub Main()
    Try
      Console.WriteLine("Пример прохождения авторизации на сайте http://yandex.ru")
      Console.WriteLine("Автор: Немиро Алексей, mailto:aleksey@kbyte.ru")
      Console.WriteLine("Copyright (c) Nemiro AS, 2007")
      Console.WriteLine("Специально для проекта Kbyte.Ru (http://kbyte.ru)")
      Console.WriteLine("")
      Console.WriteLine("Введите логин: ")
      Dim sLogin As String = Console.ReadLine()
      Console.WriteLine("Введите пароль: ")
      Dim sPassword As String = Console.ReadLine()

      Console.WriteLine("Использовать прокси-сервер? (true/false)")
      Dim bProxy As Boolean = False
      Boolean.TryParse(Console.ReadLine(), bProxy)
      Dim sProxyAddress As String = "127.0.0.1", iProxyPort As Integer = 8888
      If bProxy Then
        Console.WriteLine("Укажите адрес (например, 127.0.0.1)")
        sProxyAddress = Console.ReadLine()
        Console.WriteLine("Укажите порт (8888)")
        Integer.TryParse(Console.ReadLine(), iProxyPort)
      End If

      Console.WriteLine("")
      Console.WriteLine("Login: " & sLogin)
      Console.WriteLine("Password: " & sPassword)
      Console.WriteLine("Proxy: " & IIf(bProxy, sProxyAddress & " @ " & iProxyPort.ToString, "none"))
      Console.WriteLine("Выполяется авторизация, ждите..")

      Dim myHttpWebRequest As HttpWebRequest = HttpWebRequest.Create("http://yandex.ru")
      If bProxy Then myHttpWebRequest.Proxy = New WebProxy(sProxyAddress, iProxyPort)
      myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;"
      myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*"
      myHttpWebRequest.Headers.Add("Accept-Language", "ru")

      'запрос на http://yandex.ru
      Dim myHttpWebResponse As HttpWebResponse = myHttpWebRequest.GetResponse()

      'получаем куки, которые возвратил http://yandex.ru
      Dim sCookies As String = ""
      If Not String.IsNullOrEmpty(myHttpWebResponse.Headers("Set-Cookie")) Then
        sCookies = myHttpWebResponse.Headers("Set-Cookie")
      End If

      'авторизация на yandex.ru
      myHttpWebRequest = HttpWebRequest.Create("http://passport.yandex.ru/passport?mode=auth")
      If bProxy Then myHttpWebRequest.Proxy = New WebProxy(sProxyAddress, iProxyPort)
      myHttpWebRequest.Method = "POST"
      myHttpWebRequest.Referer = "http://yandex.ru"
      myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;"
      myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*"
      myHttpWebRequest.Headers.Add("Accept-Language", "ru")
      myHttpWebRequest.ContentType = "application/x-www-form-urlencoded"

      'передаем куки, полученные в предыдущем запросе
      If Not String.IsNullOrEmpty(sCookies) Then
        myHttpWebRequest.Headers.Add(HttpRequestHeader.Cookie, sCookies)
      End If

      'ставим False, чтобы при получении кода 302 не делать автоматический редирект
      myHttpWebRequest.AllowAutoRedirect = False

      'передаем параметры
      Dim sQueryString As String = "retpath=http%3A%2F%2Fmail.yandex.ru%2F&timestamp=" & DateDiff(DateInterval.Second, New Date(1970, 1, 1), Now) & "&login=" & sLogin & "&passwd=" & sPassword
      Dim ByteArr As Byte() = Text.Encoding.GetEncoding(1251).GetBytes(sQueryString)
      myHttpWebRequest.ContentLength = ByteArr.Length()
      myHttpWebRequest.GetRequestStream().Write(ByteArr, 0, ByteArr.Length)

      'выполняем запрос
      myHttpWebResponse = myHttpWebRequest.GetResponse()

      'найден новый url
      Dim sLocation As String = myHttpWebResponse.Headers("Location")
      If Not String.IsNullOrEmpty(sLocation) Then
        'получам куки
        sCookies = ""
        If Not String.IsNullOrEmpty(myHttpWebResponse.Headers("Set-Cookie")) Then
          sCookies = myHttpWebResponse.Headers("Set-Cookie")
        End If
        'формируем запрос
        myHttpWebRequest = HttpWebRequest.Create("http://passport.yandex.ru" & sLocation)
        If bProxy Then myHttpWebRequest.Proxy = New WebProxy(sProxyAddress, iProxyPort)
        myHttpWebRequest.Referer = "http://passport.yandex.ru/passport?mode=auth"
        myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;"
        myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*"
        myHttpWebRequest.Headers.Add("Accept-Language", "ru")
        myHttpWebRequest.ContentType = "text/plain"
        If Not String.IsNullOrEmpty(sCookies) Then
          myHttpWebRequest.Headers.Add(HttpRequestHeader.Cookie, sCookies)
        End If

        'выполняем запрос
        myHttpWebResponse = myHttpWebRequest.GetResponse()

        'смотрим, делается ли редирект JavaScrip-ом
        If New StreamReader(myHttpWebResponse.GetResponseStream, Encoding.GetEncoding(1251)).ReadToEnd.IndexOf("window.location.replace") > 0 Then
          'входим в сервис
          myHttpWebRequest = HttpWebRequest.Create("http://mail.yandex.ru/")
          If bProxy Then myHttpWebRequest.Proxy = New WebProxy(sProxyAddress, iProxyPort)
          myHttpWebRequest.Referer = "http://passport.yandex.ru" & sLocation
          myHttpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MyIE2;"
          myHttpWebRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*"
          myHttpWebRequest.Headers.Add("Accept-Language", "ru")
          myHttpWebRequest.ContentType = "text/plain"
          If Not String.IsNullOrEmpty(sCookies) Then
            myHttpWebRequest.Headers.Add(HttpRequestHeader.Cookie, sCookies)
          End If

          'выполняем запрос
          myHttpWebResponse = myHttpWebRequest.GetResponse()
        Else
          Console.WriteLine("Данные не найдены.." & vbCrLf & "Нажмите любую клавишу для заврешения")
          Console.ReadKey()
          Return
        End If
      End If

      'выводим результат в консоль
      Dim myStreamReader As New StreamReader(myHttpWebResponse.GetResponseStream, Encoding.GetEncoding(1251))
      Console.WriteLine(myStreamReader.ReadToEnd())
    Catch ex As Exception
      Console.WriteLine("Ошибка: " & ex.ToString)
    End Try

    Console.WriteLine("Нажмите любую клавишу для завершения.")
    Console.ReadKey()
  End Sub

End Module