﻿/*
 * This is an example for article «Silverlight File Manager»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=68&mode=art
 * (russian language only)
 * Translated into English special for CodeProject
 * http://www.codeproject.com/
 * Author: Aleksey S Nemiro
 * http://aleksey.nemiro.ru
 * http://kbyte.ru
 * Copyright © Aleksey S Nemiro, 2012
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Nemiro.FileManager.MVC.Controllers
{
  public class HomeController : Controller
  {
    //
    // GET: /Home/

    /// <summary>
    /// Gateway
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    public ActionResult Gateway()
    {
      Nemiro.FileManager.Common.Gateway myGateway = new Nemiro.FileManager.Common.Gateway();
      return new ContentResult() { Content = myGateway.GetResult(), ContentType = "application/json", ContentEncoding = System.Text.Encoding.UTF8 };
    }

  }
}
