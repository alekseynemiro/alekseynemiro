﻿/*
 * This is an example for article «Silverlight File Manager»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=68&mode=art
 * (russian language only)
 * Translated into English special for CodeProject
 * http://www.codeproject.com/
 * Author: Aleksey S Nemiro
 * http://aleksey.nemiro.ru
 * http://kbyte.ru
 * Copyright © Aleksey S Nemiro, 2012
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Collections;
using System.Web.Script.Serialization;
using System.Text;

namespace Nemiro.FileManager.Web
{
  /// <summary>
  /// Gateway
  /// </summary>
  public class Gateway : IHttpHandler
  {

    public void ProcessRequest(HttpContext context)
    {
      Nemiro.FileManager.Common.Gateway myGateway = new Nemiro.FileManager.Common.Gateway();
      context.Response.ContentType = "application/json";
      context.Response.Write(myGateway.GetResult());
    }

    public bool IsReusable
    {
      get
      {
        return false;
      }
    }
  }
}