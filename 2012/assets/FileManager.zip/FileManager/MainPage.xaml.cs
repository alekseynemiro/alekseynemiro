﻿/*
 * This is an example for article «Silverlight File Manager»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=68&mode=art
 * (russian language only)
 * Translated into English special for CodeProject
 * http://www.codeproject.com/
 * Author: Aleksey S Nemiro
 * http://aleksey.nemiro.ru
 * http://kbyte.ru
 * Copyright © Aleksey S Nemiro, 2012
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Text;
using System.Windows.Browser;

namespace Nemiro.FileManager
{
  public partial class MainPage : UserControl
  {
    /*
     * ATTENTION! PLEASE CHECK SERVER URL! 
     */
    private string _Url = "http://localhost:58646/Gateway.ashx"; // gateway url for requests
    // http://localhost:58646/Gateway.ashx // webforms (check port number)
    // http://localhost:62263/Home/Gateway //mvc (check port number)

    PleaseWait myPleaseWait = null; // progressbar

    public MainPage()
    {
      InitializeComponent();

      fileList1.Url = _Url; //set url

      // handlers for progress
      fileList1.Process += new EventHandler(fileList1_Process);
      fileList1.Complete += new EventHandler(fileList1_Complete);

      //fileList1.UpdateFileList();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
    }

    private void fileList1_Process(object sender, EventArgs e)
    {
      this.Dispatcher.BeginInvoke(() =>
      {
        if (myPleaseWait != null && myPleaseWait.Visibility == System.Windows.Visibility.Visible) return;
        // show porgress
        myPleaseWait = new PleaseWait();
        myPleaseWait.Show();
      });
    }

    private void fileList1_Complete(object sender, EventArgs e)
    {
      this.Dispatcher.BeginInvoke(() =>
      {
        //close progress
        if (myPleaseWait != null)
        {
          myPleaseWait.Close();
          myPleaseWait = null;
        }
        // set new path from fileList
        tbPath.Text = fileList1.Path;
      });
    }


    /// <summary>
    /// Create New Directory button click handler
    /// </summary>
    private void btnCreateDir_Click(object sender, RoutedEventArgs e)
    {
      // init the Prompt Window
      Prompt myPrompt = new Prompt("Input", "Please, input directory name:");

      // add closed handlers to the Prompt Window
      myPrompt.Closed += (s, args) =>
      {
        if (!myPrompt.DialogResult.Value) return;// name is empty
        // name is not empty, send request for create a new directory
        fileList1.CreateDirectory(myPrompt.InputValue);
      };

      // show the Prompt Window
      myPrompt.Show();
    }

    /// <summary>
    /// Selected files button click handler
    /// </summary>
    private void btnUploadFile_Click(object sender, RoutedEventArgs e)
    {
      // show open file dialog
      OpenFileDialog op = new OpenFileDialog() { Filter = "Images|*.jpg;*.jpeg;*.gif;*.png|Documents|*.txt;*.rtf;*.doc;*.docx;*.xls;*.xlsx;*.pdf|Audio files|*.wav;*.mp3;*.wma|Video files|*.avi;*.mpg;*.mov;*.wmv;*.mp4;*.mpeg|All files|*.*", Multiselect = true };
      if (op.ShowDialog() != true) return; // dialog is closed

      // add files to upload list
      foreach (FileInfo f in op.Files)
      {
        fileList1.AddUploadItem(f);
      }

      // upload files
      fileList1.Upload();
    }



  }
}
