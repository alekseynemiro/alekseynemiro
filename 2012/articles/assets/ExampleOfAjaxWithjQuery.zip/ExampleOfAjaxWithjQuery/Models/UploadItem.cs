﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/*
 * Пример к статье «Асинхронные запросы в JavaScript»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=70&mode=art
 * Автор: Алексей Немиро
 * http://aleksey.nemiro.ru
 * 27 января 2012 года
 * 
 * Специально для Kbyte.Ru
 * http://kbyte.ru
 * Copyright © Aleksey Nemiro, 2012
 */

namespace ExampleOfAjaxWithjQuery.Models
{

  public class UploadItem
  {

    public Guid Id { get; set; }
    public long FileLength { get; set; }
    public long BytesReceived { get; set; }
    public bool FileUploded { get; set; }

  }
}