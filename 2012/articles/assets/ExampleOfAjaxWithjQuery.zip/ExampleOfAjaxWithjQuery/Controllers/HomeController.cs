﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading;
using System.Data;
using System.Collections;
using System.IO;
using System.Text;

/*
 * Пример к статье «Асинхронные запросы в JavaScript»
 * http://kbyte.ru/ru/Programming/Articles.aspx?id=70&mode=art
 * Автор: Алексей Немиро
 * http://aleksey.nemiro.ru
 * 27 января 2012 года
 * 
 * Специально для Kbyte.Ru
 * http://kbyte.ru
 * Copyright © Aleksey Nemiro, 2012
 */

namespace ExampleOfAjaxWithjQuery.Controllers
{
  [HandleError]
  public class HomeController : Controller
  {

    #region простые запросы
    public ActionResult Index()
    {
      return View();
    }

    public ActionResult AjaxHelloWorld()
    {
      return new ContentResult() {
        Content = "Привет, мир!<br />Эти данные получены асихронным методом!<br />Хотите узнать больше? Просто <a href=\"http://kbyte.ru/ru/Forums?id=0\" target=\"_blank\">спросите</a>!", 
        ContentType = "text/html" 
      };
    }

    [HttpPost]
    public ActionResult AjaxPost(string name, string age, string url)
    {
      return new ContentResult()
      {
        Content = String.Format("Данные получены!\r\nИмя: {0}\r\nВозраст: {1} лет\r\nАдрес: {2}", name, age, url),
        ContentType = "text/html"
      };
    }

    [HttpPost]
    public ActionResult JsonExample()
    {
      ArrayList data = new ArrayList();

      data.Add(new { firstName = "Василий", lastName = "Пупкин", sex = "муж." });
      data.Add(new { firstName = "Маша", lastName = "Иванова", sex = "жен." });
      data.Add(new { firstName = "Федя", lastName = "Петров", sex = "муж." });
      data.Add(new { firstName = "Света", lastName = "Шашечкина", sex = "жен." });

      return new JsonResult() { Data = new { status = "ok", table = data } };
    }
    #endregion
    #region файлы
    public ActionResult FileUpload()
    {
      return View();
    }

    [HttpPost]
    public ActionResult FileUpload(HttpPostedFileBase file1)
    {
      Thread.Sleep(5000); // пауза, для наглядности
      return new ContentResult()
      {
        Content = String.Format("Имя файла: {0}\r\nТип файла: {1}\r\nРазмер: {2} байт", file1.FileName, file1.ContentType, file1.ContentLength),
        ContentType = "text/plain"
      };
    }

    public ActionResult FileUploadWithProgress()
    {
      // необходимо создать (и аннулировать) сессию, иначе работать не будет
      Session["File"] = new Models.UploadItem();

      return View();
    }

    /*
     * На локальном сервере,
     * Если загружать файл маленького размера, то прогресс будет не заметен.
     * Если загружать файл большого размера (1-2 Гб), локальный сервер (т.е. вам компьютер) может тупить, в зависимости от характеристик (оперативка, скорость hdd, файл подкачки и т.п.).
     * (локально проверял работу под ASP .NET Development Server, загружая файл размером 1.75 Гб).
     * Именно поэтому в статье я создавал искусственные задержки, чтобы было видно, как это работает.
     * 
     * На нормальном сервере (который находится в интернете или в сети, под IIS), все будет работать как задумано.
     */
    [HttpPost]
    public ActionResult FileUploadWithProgress(HttpPostedFileBase file1)
    {
      try
      {
        Models.UploadItem itm = new Models.UploadItem();
        itm.FileLength = file1.ContentLength;// размер файла

        Session["File"] = itm; //передаем файл в сессию

        // сохраняем файл на диск
        DirectoryInfo DI = new DirectoryInfo(Server.MapPath("~/Upload"));
        // если папка не существует, создаем
        if (!DI.Exists) DI.Create();

        using (FileStream fs = new FileStream(Path.Combine(DI.FullName, file1.FileName), FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
        {
          using (BinaryWriter br = new BinaryWriter(fs, Encoding.UTF8))
          {
            byte[] buffer = new byte[4096];
            int readBytes = 0;
            while ((readBytes = file1.InputStream.Read(buffer, 0, buffer.Length)) > 0)
            {
              br.Write(buffer, 0, readBytes);
              itm.BytesReceived += readBytes; //увеличиваем счетчик полученных байт
            }
          }
        }

        itm.FileUploded = true;

        return new ContentResult()
        {
          Content = String.Format("Имя файла: {0}\r\nТип файла: {1}\r\nРазмер: {2} байт", file1.FileName, file1.ContentType, file1.ContentLength),
          ContentType = "text/plain"
        };
      }
      catch (Exception ex)
      {
        return new ContentResult()
        {
          Content = ex.Message,
          ContentType = "text/plain"
        };
      }
    }

    #region фрагмент кода, описанный (не путать с 'обоссанный') в статье
    /*
    [HttpPost]
    public ActionResult FileUploadWithProgress(HttpPostedFileBase file1)
    {
      Models.UploadItem itm = new Models.UploadItem();
      itm.FileLength = file1.ContentLength;// размер файла

      Session["File"] = itm; //передаем файл в сессию

      // Для демонстрации работы примера, файл загружается в отдельном потоке, чтобы не блокировать основной поток.
      // На "живом" сервер так делать необязательно.
      Thread t = new Thread(ThreadUpload);
      t.IsBackground = true;
      t.Start(new object[] { HttpContext.Session, file1 });

      return new ContentResult()
      {
        Content = String.Format("Имя файла: {0}\r\nТип файла: {1}\r\nРазмер: {2} байт", file1.FileName, file1.ContentType, file1.ContentLength),
        ContentType = "text/plain"
      };
    }

    private void ThreadUpload(object args)
    {
      HttpSessionStateBase session = ((Array)args).GetValue(0) as HttpSessionStateBase;
      HttpPostedFileBase file1 = ((Array)args).GetValue(1) as HttpPostedFileBase;
      Models.UploadItem itm = session["File"] as Models.UploadItem;

      byte[] buffer = new byte[1024];
      int readBytes = 0;
      while ((readBytes = file1.InputStream.Read(buffer, 0, buffer.Length)) > 0)
      {
        itm.BytesReceived += readBytes; //увеличиваем счетчик полученных байт
        Thread.Sleep(1000);// пауза 1 сек., для наглядности
      }

      // ставим отметку о том, что файл загружен
      itm.FileUploded = true;
    }
    */
    #endregion

    [HttpPost]
    public ActionResult FileUploadCheck()
    {
      // передаем информацию о состоянии загружаемого файла
      return new JsonResult() { Data = Session["File"] };// передаем объект (класс), он автоматически будет преобразован в JSON
    }
    #endregion
  
  }
}
