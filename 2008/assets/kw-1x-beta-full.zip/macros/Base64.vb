Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Windows.Forms
Imports System.Drawing
Imports System.IO
Imports System.Text

''' <![CDATA[
''' <kbyteWorldMacros>
'''   <name>Base64</name>
'''   <version>1.0</version>
'''   <author>Aleksey S Nemiro</author>
'''   <mail>admin@kbyte.ru</mail>
'''   <urls>http://kbyte.ru,http://aleksey.nemiro.ru</urls>
'''   <copyright>Copyright � Nemiro AS, 2008</copyright>
'''   <description>
'''   ������������ ��������� ���� � Base64 � �������.
'''   </description>
'''   <legal>
'''   - ���������, ������������ ������ ������ �� ������ ����������.
'''   - ����� �� ����� ��������������� �� ����������� ������������� ������� �������. 
'''   - ������ �� ��������������� ������ �����������.
'''   </legal>
''' </kbyteWorldMacros>
''' ]]>
Public Class KbyteWorldMacros
#Region "���� ��� ������������ Kbyte World Macros Creator v.1.0"
#Region ">> !�� ��������� ������ ���! <<"
  '
  ' � ������ ���� ���������� 
  ' ������ �� ��������� ������� � KbyteWorld.exe,
  ' ����� KbyteWorld.exe � ������ ����� ����������������� 
  ' ���� � ������.
  '
  Private _Macros As Kbyte.World.Macros

  Public Sub New(ByVal m As Kbyte.World.Macros)
    _Macros = m
  End Sub

  '
  ' ��� ��������� ������� � ���������� ������� � KbyteWorld.exe
  ' ����������� ���������� _Macros
  '
#End Region

  Public MainFormClosing As Boolean = False '��� ���� � ������������� �� �������
  Public LenaForm As Form
  Public MainForm As Form

  ''' <summary>
  ''' ������ �������
  ''' </summary>
  ''' <param name="f">������ �� �������� ����� Kbyte World</param>
  Public Sub Run(ByVal f As Form)
    LenaForm = f
    MainForm = New Form1(Me)
    MainForm.MdiParent = f
    MainForm.Show()
    '>> !�� ��������� ���� ����������� ���! <<
    '
    ' ������ ��� �������� ���������� � KbyteWorld.exe
    ' � ���, ��� ������ ������� � ��������.
    '
    If _Macros IsNot Nothing Then _Macros.IsRun = True
  End Sub

  ''' <summary>
  ''' ���������� ������ �������
  ''' </summary>
  Public Sub [Stop]()
    If MainForm IsNot Nothing AndAlso Not MainFormClosing Then
      MainForm.Close()
      MainFormClosing = True
      MainForm = Nothing
    End If
    ' >> !�� ��������� ���� ����������� ���! <<
    '
    ' ������ ��� �������� ���������� � KbyteWorld.exe
    ' � ���, ��� ������ �������� ���� ������.
    '
    If _Macros IsNot Nothing Then _Macros.IsRun = False
  End Sub
#End Region

#Region "Form1"
  Public Class Form1

    Private _kwm As KbyteWorldMacros

    Public Sub New(ByVal kwm As KbyteWorldMacros)
      _kwm = kwm
      InitializeComponent()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      'file2base64
      If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Using sr As New StreamReader(OpenFileDialog1.FileName, Encoding.GetEncoding(1251))
          Dim result As New Form2()
          result.TextBox1.Text = Convert.ToBase64String(Encoding.GetEncoding(1251).GetBytes(sr.ReadToEnd()))
          If _kwm IsNot Nothing AndAlso _kwm.LenaForm IsNot Nothing Then result.MdiParent = _kwm.LenaForm
          result.Show()
        End Using
      End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
      'bae64ToFile
      Dim result As New Form2()
      result.TextBox1.Text = "�������� ���� ����� � Base64"
      result.TableLayoutPanel1.Visible = True
      If _kwm IsNot Nothing AndAlso _kwm.LenaForm IsNot Nothing Then result.MdiParent = _kwm.LenaForm
      result.Show()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
      Call New Form3().ShowDialog()
    End Sub

    Private Sub Form1_Closing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
      If _kwm IsNot Nothing Then
        _kwm.MainFormClosing = True
        _kwm.Stop()
      End If
    End Sub

  End Class
#Region "Ÿ���� ��������"
  <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
  Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
        If disposing AndAlso components IsNot Nothing Then
          components.Dispose()
        End If
      Finally
        MyBase.Dispose(disposing)
      End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
      Me.Button1 = New System.Windows.Forms.Button
      Me.Button2 = New System.Windows.Forms.Button
      Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
      Me.Button3 = New System.Windows.Forms.Button
      Me.SuspendLayout()
      '
      'Button1
      '
      Me.Button1.Location = New System.Drawing.Point(12, 12)
      Me.Button1.Name = "Button1"
      Me.Button1.Size = New System.Drawing.Size(182, 28)
      Me.Button1.TabIndex = 0
      Me.Button1.Text = "File to Base64"
      Me.Button1.UseVisualStyleBackColor = True
      '
      'Button2
      '
      Me.Button2.Location = New System.Drawing.Point(200, 12)
      Me.Button2.Name = "Button2"
      Me.Button2.Size = New System.Drawing.Size(182, 28)
      Me.Button2.TabIndex = 1
      Me.Button2.Text = "Base64 to File"
      Me.Button2.UseVisualStyleBackColor = True
      '
      'OpenFileDialog1
      '
      Me.OpenFileDialog1.Filter = "��� ����� (*.*) | *.*"
      '
      'Button3
      '
      Me.Button3.Location = New System.Drawing.Point(86, 46)
      Me.Button3.Name = "Button3"
      Me.Button3.Size = New System.Drawing.Size(233, 28)
      Me.Button3.TabIndex = 2
      Me.Button3.Text = "� ���������..."
      Me.Button3.UseVisualStyleBackColor = True
      '
      'Form1
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(391, 82)
      Me.Controls.Add(Me.Button3)
      Me.Controls.Add(Me.Button2)
      Me.Controls.Add(Me.Button1)
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.MaximizeBox = False
      Me.Name = "Form1"
      Me.Text = "Base64 @ Aleksey S Nemiro :: 12.04.2008"
      Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button3 As System.Windows.Forms.Button

  End Class
#End Region
#End Region
#Region "Form2"
  Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim b() As Byte = Nothing
        Try
          b = Convert.FromBase64String(TextBox1.Text)
        Catch ex As Exception
          MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        If b IsNot Nothing Then
          Using sw As New StreamWriter(SaveFileDialog1.FileName, False, Encoding.GetEncoding(1251))
            sw.Write(Encoding.GetEncoding(1251).GetString(b))
          End Using
          MessageBox.Show("���� ������� ��������!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
      End If
    End Sub

  End Class

#Region "Ÿ���� ��������"
  <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
  Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
        If disposing AndAlso components IsNot Nothing Then
          components.Dispose()
        End If
      Finally
        MyBase.Dispose(disposing)
      End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
      Me.TextBox1 = New System.Windows.Forms.TextBox
      Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
      Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
      Me.Button1 = New System.Windows.Forms.Button
      Me.TableLayoutPanel1.SuspendLayout()
      Me.SuspendLayout()
      '
      'TextBox1
      '
      Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
      Me.TextBox1.Location = New System.Drawing.Point(0, 0)
      Me.TextBox1.Multiline = True
      Me.TextBox1.Name = "TextBox1"
      Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.TextBox1.Size = New System.Drawing.Size(441, 226)
      Me.TextBox1.TabIndex = 0
      '
      'SaveFileDialog1
      '
      Me.SaveFileDialog1.Filter = "��� ����� (*.*) | *.*"
      '
      'TableLayoutPanel1
      '
      Me.TableLayoutPanel1.ColumnCount = 2
      Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
      Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
      Me.TableLayoutPanel1.Controls.Add(Me.Button1, 1, 0)
      Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 226)
      Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
      Me.TableLayoutPanel1.RowCount = 1
      Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
      Me.TableLayoutPanel1.Size = New System.Drawing.Size(441, 30)
      Me.TableLayoutPanel1.TabIndex = 1
      Me.TableLayoutPanel1.Visible = False
      '
      'Button1
      '
      Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
      Me.Button1.Location = New System.Drawing.Point(324, 3)
      Me.Button1.Name = "Button1"
      Me.Button1.Size = New System.Drawing.Size(114, 24)
      Me.Button1.TabIndex = 1
      Me.Button1.Text = "���������"
      Me.Button1.UseVisualStyleBackColor = True
      '
      'Form2
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(441, 256)
      Me.Controls.Add(Me.TextBox1)
      Me.Controls.Add(Me.TableLayoutPanel1)
      Me.Name = "Form2"
      Me.Text = "Base64"
      Me.TableLayoutPanel1.ResumeLayout(False)
      Me.ResumeLayout(False)
      Me.PerformLayout()

    End Sub
    Public WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Public WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button1 As System.Windows.Forms.Button
  End Class
#End Region
#End Region
#Region "Form3"
  Public Class Form3
    Private photo As String = "/9j/4AAQSkZJRgABAgEAYABgAAD/4Qc9RXhpZgAATU0AKgAAAAgABwESAAMAAAABAAEAAAEaAAUAAAABAAAAYgEbAAUAAAABAAAAagEoAAMAAAABAAIAAAExAAIAAAAcAAAAcgEyAAIAAAAUAAAAjodpAAQAAAABAAAApAAAANAADqYAAAAnEAAOpgAAACcQQWRvYmUgUGhvdG9zaG9wIENTMyBXaW5kb3dzADIwMDg6MDM6MTUgMTQ6MTI6NDkAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAZKADAAQAAAABAAAAZAAAAAAAAAAGAQMAAwAAAAEABgAAARoABQAAAAEAAAEeARsABQAAAAEAAAEmASgAAwAAAAEAAgAAAgEABAAAAAEAAAEuAgIABAAAAAEAAAYHAAAAAAAAAEgAAAABAAAASAAAAAH/2P/gABBKRklGAAECAABIAEgAAP/tAAxBZG9iZV9DTQAB/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAZABkAwEiAAIRAQMRAf/dAAQAB//EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A8qSSSSUukEgFIDWElKhKE5gKO7ySUyhNCW7xCcEFJTGEymQokJKYpJymSUpJJJJT/9DypOEycJKXCdN2RqaS8SNSeAkpE1k6nhFIaGxEFTfS9oG0T5jxSrocYc4EzwPFJTXI7wUxb4Lfr6Xbdih9LHO3mC0tgD/i59yqHoOeDBqd4cFJTmhrwJPCYrTy8O3GaG2sLQBws5wAMDjskpGUykonVJSkkoSSU//R8qThMphJSoKudMp9e+usmG/nKqfoq/0OftjfAcpKe0wOiYl9lfqVj0qhoz94nu5aF3Qasg3X+kGhtYZQQIgk/m/2UTpbS9ojjxXQVUyxocJAgx8ElMKunV01NqDQdo5gcqlm0NAPktov0juVm5tbgCUlPC/WWlrsd3iNQuMsZDiF3H1jaDS/z5XE2zvIOhHZJSD6Wg4THTRSLtICjB7pKW7pJ9EklP8A/9LyoKYUFIJKZ8hWMDJGLd6rgXNA7ILG7jHjojY+G63IbRu2+poHdp5SU9V0z670Y7Gse10j+TI/Kup6V9eOn5dgxtwqtI0B0/L9FefD6s9XpBe3GdcfzXVkH8DCL036u9ZfnUuyKH49O8erY+B7Z9zf7SSn0nP+tXTsNu92RU5wGgDgR89qwMr684VlZssuIaeBTWXAfF7nKr9eeg3ZBou6Xjjaxu26ipobx9C3aPpLl8boHXXvLBgXFp5DgGj4+4pKdDP+sOHnTXWH2OcRG5u3vruXO3O3WOcdC4kras+r+R03HsvyyG3OBbXU0zE8uc5YtrC1wCSkPtA8SokkqewRJPyUSWjhJTBJPKSSn//T8qCI1oUFNpSU2Kw0/FWWvbU6mwH6DwT8D7VUY4BGlr2xwHCCkp9H6RmNNTddYV269j8yn1nbaQPa4/R3/wAoriehdVLa/s9pi2se09nBb1PU3l3pvYx7TrDikp3c21gurOPYH2SI2aiP5SJkZft1OvxWO7qbaQGsqaAf3XBU8rqw2Eu0PDW9yUlOb9Zsz1Lm1t7SdFzd4DR7tSVodUyA/I2kyWj3kfvHt/ZWa6xm6dZH0e8JKa1rPHQ+CC4EI7/E6oLj2SUwSTpJKf/U8qUgVFJJSVpRq3xA/KqwKm12qSm7TYN0btjpmuz913n/ACHLawesVAenkgMtbo5ruPi1c0HFWGWteAHgOjglJT1FnVcQCWbXPPAbys7JzvT/AEjoNzv5tvZo/eWa25tQOwAFVrLnOcXEyUlJX2zJ7k6k+KA9yiXqBckpdzkMpEpklKSSSSU//9XypJJJJS4TiVFJJSTVTZu7ICSSm07chGZQkklMzKZRSSUumSSSUpJJJJT/AP/Z/+0MOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAHHAIAAAIARAA4QklNBCUAAAAAABD7i5HdaeovCkCA/FF/R016OEJJTQQvAAAAAABKyLABAFgCAABYAgAAAAAAAAAAAACnGgAAoxIAAKL///+i////CRsAAAITAAAAAXsFAADgAwAAAQAPJwEAbGx1bgAAAAAAAAAAAAA4QklNA+0AAAAAABAAYAAAAAEAAgBgAAAAAQACOEJJTQQmAAAAAAAOAAAAAAAAAAAAAD+AAAA4QklNBA0AAAAAAAQAAAB4OEJJTQQZAAAAAAAEAAAAHjhCSU0D8wAAAAAACQAAAAAAAAAAAQA4QklNBAoAAAAAAAEAADhCSU0nEAAAAAAACgABAAAAAAAAAAI4QklNA/UAAAAAAEgAL2ZmAAEAbGZmAAYAAAAAAAEAL2ZmAAEAoZmaAAYAAAAAAAEAMgAAAAEAWgAAAAYAAAAAAAEANQAAAAEALQAAAAYAAAAAAAE4QklNA/gAAAAAAHAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAOEJJTQQIAAAAAAAQAAAAAQAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAAzsAAAAGAAAAAAAAAAAAAABkAAAAZAAAAAMAMABtAGUAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAGQAAABkAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAEAAAAAAABudWxsAAAAAgAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAABkAAAAAFJnaHRsb25nAAAAZAAAAAZzbGljZXNWbExzAAAAAU9iamMAAAABAAAAAAAFc2xpY2UAAAASAAAAB3NsaWNlSURsb25nAAAAAAAAAAdncm91cElEbG9uZwAAAAAAAAAGb3JpZ2luZW51bQAAAAxFU2xpY2VPcmlnaW4AAAANYXV0b0dlbmVyYXRlZAAAAABUeXBlZW51bQAAAApFU2xpY2VUeXBlAAAAAEltZyAAAAAGYm91bmRzT2JqYwAAAAEAAAAAAABSY3QxAAAABAAAAABUb3AgbG9uZwAAAAAAAAAATGVmdGxvbmcAAAAAAAAAAEJ0b21sb25nAAAAZAAAAABSZ2h0bG9uZwAAAGQAAAADdXJsVEVYVAAAAAEAAAAAAABudWxsVEVYVAAAAAEAAAAAAABNc2dlVEVYVAAAAAEAAAAAAAZhbHRUYWdURVhUAAAAAQAAAAAADmNlbGxUZXh0SXNIVE1MYm9vbAEAAAAIY2VsbFRleHRURVhUAAAAAQAAAAAACWhvcnpBbGlnbmVudW0AAAAPRVNsaWNlSG9yekFsaWduAAAAB2RlZmF1bHQAAAAJdmVydEFsaWduZW51bQAAAA9FU2xpY2VWZXJ0QWxpZ24AAAAHZGVmYXVsdAAAAAtiZ0NvbG9yVHlwZWVudW0AAAARRVNsaWNlQkdDb2xvclR5cGUAAAAATm9uZQAAAAl0b3BPdXRzZXRsb25nAAAAAAAAAApsZWZ0T3V0c2V0bG9uZwAAAAAAAAAMYm90dG9tT3V0c2V0bG9uZwAAAAAAAAALcmlnaHRPdXRzZXRsb25nAAAAAAA4QklNBCgAAAAAAAwAAAABP/AAAAAAAAA4QklNBBQAAAAAAAQAAAADOEJJTQQMAAAAAAYjAAAAAQAAAGQAAABkAAABLAAAdTAAAAYHABgAAf/Y/+AAEEpGSUYAAQIAAEgASAAA/+0ADEFkb2JlX0NNAAH/7gAOQWRvYmUAZIAAAAAB/9sAhAAMCAgICQgMCQkMEQsKCxEVDwwMDxUYExMVExMYEQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQ0LCw0ODRAODhAUDg4OFBQODg4OFBEMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCABkAGQDASIAAhEBAxEB/90ABAAH/8QBPwAAAQUBAQEBAQEAAAAAAAAAAwABAgQFBgcICQoLAQABBQEBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAEEAQMCBAIFBwYIBQMMMwEAAhEDBCESMQVBUWETInGBMgYUkaGxQiMkFVLBYjM0coLRQwclklPw4fFjczUWorKDJkSTVGRFwqN0NhfSVeJl8rOEw9N14/NGJ5SkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2N0dXZ3eHl6e3x9fn9xEAAgIBAgQEAwQFBgcHBgU1AQACEQMhMRIEQVFhcSITBTKBkRShsUIjwVLR8DMkYuFygpJDUxVjczTxJQYWorKDByY1wtJEk1SjF2RFVTZ0ZeLys4TD03Xj80aUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9ic3R1dnd4eXp7fH/9oADAMBAAIRAxEAPwDypJJJJS6QSAUgNYSUqEoTmAo7vJJTKE0JbvEJwQUlMYTKZCiQkpiknKZJSkkkklP/0PKk4TJwkpcJ03ZGppLxI1J4CSkTWTqeEUhobEQVN9L2gbRPmPFKuhxhzgTPA8UlNcjvBTFvgt+vpdt2KH0sc7eYLS2AP+Ln3Koeg54MGp3hwUlOaGvAk8JitPLw7cZobawtAHCznAAwOOySkZTKSidUlKSShJJT/9HypOEymElKgq50yn1766yYb+cqp+ir/Q5+2N8Bykp7TA6JiX2V+pWPSqGjP3ie7loXdBqyDdf6QaG1hlBAiCT+b/ZROltL2iOPFdBVTLGhwkCDHwSUwq6dXTU2oNB2jmByqWbQ0A+S2i/SO5Wbm1uAJSU8L9ZaWux3eI1C4yxkOIXcfWNoNL/PlcTbO8g6EdklIPpaDhMdNFIu0gKMHukpbukn0SSU/wD/0vKgphQUgkpnyFYwMkYt3quBc0DsgsbuMeOiNj4brchtG7b6mgd2nlJT1XTPrvRjsax7XSP5Mj8q6npX146fl2DG3Cq0jQHT8v0V58Pqz1ekF7cZ1x/NdWQfwMIvTfq71l+dS7Iofj07x6tj4Htn3N/tJKfSc/61dOw273ZFTnAaAOBHz2rAyvrzhWVmyy4hp4FNZcB8Xucqv156DdkGi7peONrG7bqKmhvH0Ldo+kuXxugdde8sGBcWnkOAaPj7ikp0M/6w4edNdYfY5xEbm7e+u5c7c7dY5x0LiStqz6v5HTcey/LIbc4FtdTTMTy5zli2sLXAJKQ+0DxKiSSp7BEk/JRJaOElMEk8pJKf/9PyoIjWhQU2lJTYrDT8VZa9tTqbAfoPBPwPtVRjgEaWvbHAcIKSn0fpGY01N11hXbr2PzKfWdtpA9rj9Hf/ACiuJ6F1Utr+z2mLax7T2cFvU9TeXem9jHtOsOKSndzbWC6s49gfZIjZqI/lImRl+3U6/FY7uptpAaypoB/dcFTyurDYS7Q8Nb3JSU5v1mzPUubW3tJ0XN3gNHu1JWh1TID8jaTJaPeR+8e39lZrrGbp1kfR7wkprWs8dD4ILgQjv8TqguPZJTBJOkkp/9TypSBUUklJWlGrfED8qrAqbXapKbtNg3Ru2Oma7P3Xef8AIctrB6xUB6eSAy1ujmu4+LVzQcVYZa14AeA6OCUlPUWdVxAJZtc88BvKzsnO9P8ASOg3O/m29mj95Zrbm1A7AAVWsuc5xcTJSUlfbMnuTqT4oD3KJeoFySl3OQykSmSUpJJJJT//1fKkkkklLhOJUUklJNVNm7sgJJKbTtyEZlCSSUzMplFJJS6ZJJJSkkkklP8A/9kAOEJJTQQhAAAAAABVAAAAAQEAAAAPAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwAAAAEwBBAGQAbwBiAGUAIABQAGgAbwB0AG8AcwBoAG8AcAAgAEMAUwAzAAAAAQA4QklNBAYAAAAAAAcABgEBAAEBAP/hD85odHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDQuMS1jMDM2IDQ2LjI3NjcyMCwgTW9uIEZlYiAxOSAyMDA3IDIyOjQwOjA4ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnhhcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eGFwTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIiB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyIgZGM6Zm9ybWF0PSJpbWFnZS9qcGVnIiB4YXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzMgV2luZG93cyIgeGFwOkNyZWF0ZURhdGU9IjIwMDgtMDMtMTVUMTQ6MTI6NDkrMTA6MDAiIHhhcDpNb2RpZnlEYXRlPSIyMDA4LTAzLTE1VDE0OjEyOjQ5KzEwOjAwIiB4YXA6TWV0YWRhdGFEYXRlPSIyMDA4LTAzLTE1VDE0OjEyOjQ5KzEwOjAwIiB4YXBNTTpEb2N1bWVudElEPSJ1dWlkOjI5Mzg2ODA0NDZGMkRDMTFCQTEwQzZBMkQ4Qjc1MEU0IiB4YXBNTTpJbnN0YW5jZUlEPSJ1dWlkOjJBMzg2ODA0NDZGMkRDMTFCQTEwQzZBMkQ4Qjc1MEU0IiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHBob3Rvc2hvcDpIaXN0b3J5PSIiIHRpZmY6T3JpZW50YXRpb249IjEiIHRpZmY6WFJlc29sdXRpb249Ijk2MDAwMC8xMDAwMCIgdGlmZjpZUmVzb2x1dGlvbj0iOTYwMDAwLzEwMDAwIiB0aWZmOlJlc29sdXRpb25Vbml0PSIyIiB0aWZmOk5hdGl2ZURpZ2VzdD0iMjU2LDI1NywyNTgsMjU5LDI2MiwyNzQsMjc3LDI4NCw1MzAsNTMxLDI4MiwyODMsMjk2LDMwMSwzMTgsMzE5LDUyOSw1MzIsMzA2LDI3MCwyNzEsMjcyLDMwNSwzMTUsMzM0MzI7Qjk1MUY2NjBDQUM1N0I2QzUxNUIwRjY0QkMxNkMzODciIGV4aWY6UGl4ZWxYRGltZW5zaW9uPSIxMDAiIGV4aWY6UGl4ZWxZRGltZW5zaW9uPSIxMDAiIGV4aWY6Q29sb3JTcGFjZT0iMSIgZXhpZjpOYXRpdmVEaWdlc3Q9IjM2ODY0LDQwOTYwLDQwOTYxLDM3MTIxLDM3MTIyLDQwOTYyLDQwOTYzLDM3NTEwLDQwOTY0LDM2ODY3LDM2ODY4LDMzNDM0LDMzNDM3LDM0ODUwLDM0ODUyLDM0ODU1LDM0ODU2LDM3Mzc3LDM3Mzc4LDM3Mzc5LDM3MzgwLDM3MzgxLDM3MzgyLDM3MzgzLDM3Mzg0LDM3Mzg1LDM3Mzg2LDM3Mzk2LDQxNDgzLDQxNDg0LDQxNDg2LDQxNDg3LDQxNDg4LDQxNDkyLDQxNDkzLDQxNDk1LDQxNzI4LDQxNzI5LDQxNzMwLDQxOTg1LDQxOTg2LDQxOTg3LDQxOTg4LDQxOTg5LDQxOTkwLDQxOTkxLDQxOTkyLDQxOTkzLDQxOTk0LDQxOTk1LDQxOTk2LDQyMDE2LDAsMiw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwyMCwyMiwyMywyNCwyNSwyNiwyNywyOCwzMDs5MjVGQ0Y2MkFFREE2QTYzQkEyMzY4NzFCRTcxN0E2RCI+IDx4YXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ1dWlkOkM3N0IxOTMzOUE2Q0RDMTE4RDA3Q0YwOUEzQkIyMjEzIiBzdFJlZjpkb2N1bWVudElEPSJ1dWlkOkM2N0IxOTMzOUE2Q0RDMTE4RDA3Q0YwOUEzQkIyMjEzIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw/eHBhY2tldCBlbmQ9InciPz7/4gxYSUNDX1BST0ZJTEUAAQEAAAxITGlubwIQAABtbnRyUkdCIFhZWiAHzgACAAkABgAxAABhY3NwTVNGVAAAAABJRUMgc1JHQgAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLUhQICAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFjcHJ0AAABUAAAADNkZXNjAAABhAAAAGx3dHB0AAAB8AAAABRia3B0AAACBAAAABRyWFlaAAACGAAAABRnWFlaAAACLAAAABRiWFlaAAACQAAAABRkbW5kAAACVAAAAHBkbWRkAAACxAAAAIh2dWVkAAADTAAAAIZ2aWV3AAAD1AAAACRsdW1pAAAD+AAAABRtZWFzAAAEDAAAACR0ZWNoAAAEMAAAAAxyVFJDAAAEPAAACAxnVFJDAAAEPAAACAxiVFJDAAAEPAAACAx0ZXh0AAAAAENvcHlyaWdodCAoYykgMTk5OCBIZXdsZXR0LVBhY2thcmQgQ29tcGFueQAAZGVzYwAAAAAAAAASc1JHQiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAPNRAAEAAAABFsxYWVogAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z2Rlc2MAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZGVzYwAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAALFJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHZpZXcAAAAAABOk/gAUXy4AEM8UAAPtzAAEEwsAA1yeAAAAAVhZWiAAAAAAAEwJVgBQAAAAVx/nbWVhcwAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAo8AAAACc2lnIAAAAABDUlQgY3VydgAAAAAAAAQAAAAABQAKAA8AFAAZAB4AIwAoAC0AMgA3ADsAQABFAEoATwBUAFkAXgBjAGgAbQByAHcAfACBAIYAiwCQAJUAmgCfAKQAqQCuALIAtwC8AMEAxgDLANAA1QDbAOAA5QDrAPAA9gD7AQEBBwENARMBGQEfASUBKwEyATgBPgFFAUwBUgFZAWABZwFuAXUBfAGDAYsBkgGaAaEBqQGxAbkBwQHJAdEB2QHhAekB8gH6AgMCDAIUAh0CJgIvAjgCQQJLAlQCXQJnAnECegKEAo4CmAKiAqwCtgLBAssC1QLgAusC9QMAAwsDFgMhAy0DOANDA08DWgNmA3IDfgOKA5YDogOuA7oDxwPTA+AD7AP5BAYEEwQgBC0EOwRIBFUEYwRxBH4EjASaBKgEtgTEBNME4QTwBP4FDQUcBSsFOgVJBVgFZwV3BYYFlgWmBbUFxQXVBeUF9gYGBhYGJwY3BkgGWQZqBnsGjAadBq8GwAbRBuMG9QcHBxkHKwc9B08HYQd0B4YHmQesB78H0gflB/gICwgfCDIIRghaCG4IggiWCKoIvgjSCOcI+wkQCSUJOglPCWQJeQmPCaQJugnPCeUJ+woRCicKPQpUCmoKgQqYCq4KxQrcCvMLCwsiCzkLUQtpC4ALmAuwC8gL4Qv5DBIMKgxDDFwMdQyODKcMwAzZDPMNDQ0mDUANWg10DY4NqQ3DDd4N+A4TDi4OSQ5kDn8Omw62DtIO7g8JDyUPQQ9eD3oPlg+zD88P7BAJECYQQxBhEH4QmxC5ENcQ9RETETERTxFtEYwRqhHJEegSBxImEkUSZBKEEqMSwxLjEwMTIxNDE2MTgxOkE8UT5RQGFCcUSRRqFIsUrRTOFPAVEhU0FVYVeBWbFb0V4BYDFiYWSRZsFo8WshbWFvoXHRdBF2UXiReuF9IX9xgbGEAYZRiKGK8Y1Rj6GSAZRRlrGZEZtxndGgQaKhpRGncanhrFGuwbFBs7G2MbihuyG9ocAhwqHFIcexyjHMwc9R0eHUcdcB2ZHcMd7B4WHkAeah6UHr4e6R8THz4faR+UH78f6iAVIEEgbCCYIMQg8CEcIUghdSGhIc4h+yInIlUigiKvIt0jCiM4I2YjlCPCI/AkHyRNJHwkqyTaJQklOCVoJZclxyX3JicmVyaHJrcm6CcYJ0kneierJ9woDSg/KHEooijUKQYpOClrKZ0p0CoCKjUqaCqbKs8rAis2K2krnSvRLAUsOSxuLKIs1y0MLUEtdi2rLeEuFi5MLoIuty7uLyQvWi+RL8cv/jA1MGwwpDDbMRIxSjGCMbox8jIqMmMymzLUMw0zRjN/M7gz8TQrNGU0njTYNRM1TTWHNcI1/TY3NnI2rjbpNyQ3YDecN9c4FDhQOIw4yDkFOUI5fzm8Ofk6Njp0OrI67zstO2s7qjvoPCc8ZTykPOM9Ij1hPaE94D4gPmA+oD7gPyE/YT+iP+JAI0BkQKZA50EpQWpBrEHuQjBCckK1QvdDOkN9Q8BEA0RHRIpEzkUSRVVFmkXeRiJGZ0arRvBHNUd7R8BIBUhLSJFI10kdSWNJqUnwSjdKfUrESwxLU0uaS+JMKkxyTLpNAk1KTZNN3E4lTm5Ot08AT0lPk0/dUCdQcVC7UQZRUFGbUeZSMVJ8UsdTE1NfU6pT9lRCVI9U21UoVXVVwlYPVlxWqVb3V0RXklfgWC9YfVjLWRpZaVm4WgdaVlqmWvVbRVuVW+VcNVyGXNZdJ114XcleGl5sXr1fD19hX7NgBWBXYKpg/GFPYaJh9WJJYpxi8GNDY5dj62RAZJRk6WU9ZZJl52Y9ZpJm6Gc9Z5Nn6Wg/aJZo7GlDaZpp8WpIap9q92tPa6dr/2xXbK9tCG1gbbluEm5rbsRvHm94b9FwK3CGcOBxOnGVcfByS3KmcwFzXXO4dBR0cHTMdSh1hXXhdj52m3b4d1Z3s3gReG54zHkqeYl553pGeqV7BHtje8J8IXyBfOF9QX2hfgF+Yn7CfyN/hH/lgEeAqIEKgWuBzYIwgpKC9INXg7qEHYSAhOOFR4Wrhg6GcobXhzuHn4gEiGmIzokziZmJ/opkisqLMIuWi/yMY4zKjTGNmI3/jmaOzo82j56QBpBukNaRP5GokhGSepLjk02TtpQglIqU9JVflcmWNJaflwqXdZfgmEyYuJkkmZCZ/JpomtWbQpuvnByciZz3nWSd0p5Anq6fHZ+Ln/qgaaDYoUehtqImopajBqN2o+akVqTHpTilqaYapoum/adup+CoUqjEqTepqaocqo+rAqt1q+msXKzQrUStuK4trqGvFq+LsACwdbDqsWCx1rJLssKzOLOutCW0nLUTtYq2AbZ5tvC3aLfguFm40blKucK6O7q1uy67p7whvJu9Fb2Pvgq+hL7/v3q/9cBwwOzBZ8Hjwl/C28NYw9TEUcTOxUvFyMZGxsPHQce/yD3IvMk6ybnKOMq3yzbLtsw1zLXNNc21zjbOts83z7jQOdC60TzRvtI/0sHTRNPG1EnUy9VO1dHWVdbY11zX4Nhk2OjZbNnx2nba+9uA3AXcit0Q3ZbeHN6i3ynfr+A24L3hROHM4lPi2+Nj4+vkc+T85YTmDeaW5x/nqegy6LzpRunQ6lvq5etw6/vshu0R7ZzuKO6070DvzPBY8OXxcvH/8ozzGfOn9DT0wvVQ9d72bfb794r4Gfio+Tj5x/pX+uf7d/wH/Jj9Kf26/kv+3P9t////7gAhQWRvYmUAZEAAAAABAwAQAwIDBgAAAAAAAAAAAAAAAP/bAIQAAgICAgICAgICAgMCAgIDBAMCAgMEBQQEBAQEBQYFBQUFBQUGBgcHCAcHBgkJCgoJCQwMDAwMDAwMDAwMDAwMDAEDAwMFBAUJBgYJDQoJCg0PDg4ODg8PDAwMDAwPDwwMDAwMDA8MDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8IAEQgAZABkAwERAAIRAQMRAf/EAJ0AAAEEAwEBAQAAAAAAAAAAAAQDBQYIAgcJAAEKAQEAAAAAAAAAAAAAAAAAAAAAEAABAwQBBAICAwEAAAAAAAACAQMEABEFBgchEhMIECJwMSBCFBYRAAIBAwMCBAUBBwMFAAAAAAECAwARBCESBTFBUWETBhBxgSIyFCCRobHBUiPwJAdCYnKCFRIBAAAAAAAAAAAAAAAAAAAAcP/aAAwDAQECEQMRAAAA/P8An0VFRYUMzASEBITPHhQWChYFMgg+goKJGJ9FQkWMh5GYRChIDEhMyFQkfx1PFgCBmBpgbwUxPC4ubNOq5t4uMatOapzOGEwBjIOCzbh2xLgk8NInME5dkbBxI+BweSwv2X3NmlRympTAYBuBzwYPRJDdg/FwSiRMCsQwgIGYjsS0nJ2ONkkhHk5dlJzXZGgYyHIkZKC2RbMmxrco0aXIeRoAMQociSksLNGwzTJXoi4yDUImAoEDiOJLx8IYMY3AAgJnjIVCAodQ4YwYEEBM+H//2gAIAQIAAQUA/FP/2gAIAQMAAQUA/FP/2gAIAQEAAQUApEvSJQjehCkBKUEogtRClENKn8BSgG9NtfZ1AYRXyukgrtutPKYJRjaiS1KnwiXoUvQIiUSoNR4ivU61GYZdao2eox5YNnZaJOpdKv1T9BSLYcRiDyDU3ESorcDCvGOO4vyuc1V3gnfGntt07K6tGktNNGqJYrmvbSfoEvRCaDxjhf8Aoc7ofCepZ+fmOCcVsjuK48gYXGbrhGWh9lMMxK12fE8T5IT6n2hX9hS6NCtGl2eDu9du4wilMjYnDq9DdmEIbpAkAHsXGE8PlEMZTjyC34Stce4VporUiIYaLsjOqZfjT3ewWtROLPeDQNzyO9+1HHWlx9p95NMyOP3v2F0/fSzD5Ssl3RmW3jNxet0pkrVCYV8sDp7+Yz7frPy3hGeNfXfmOfvPvFwNmNic13gHnaZKnevuw8XYHKRDivjFa8Tpxxrv6girUZgL44GSSPLYxT3EW4MO4rMZuHP3HdcnEay2f21VY9l9wTI5bNMtxgyUJEV9kgWy3FbLHL7QZIgnkYmscGcpuxoOF5MmvPyeTI2CHaOWAGFydnwmZ6TkIgyJnVXzut+qLTZ2WM8iLj5yAWHyLRStI5hxrTOR5S1IGdl3csdUvKIRTXqfkdDXuXpdFtQrQOWqPIUTCUSFDyTM5pjMRcU3kcxJlyXZapRvqtG4q0q/I0N6Dv7vvULz3k/6e0/J3H5LLelvXX4//9oACAECAgY/ACn/2gAIAQMCBj8AKf/aAAgBAQEGPwD4X+I+HSuny+Hn+yK23UX1FzQuyuSOim9fagt4da+6PT50V1BHQHSunSiPH9r51oATTSOdsa/kfPsBSI0Yjna5RFG42+l6DhHCudoYrpf5jvR2ndYWv0+ooO6ERE2LnXt41cH7ex+F/wCFX+P8qV0IeWVysUVxc2FyTfoLVEMeEygMAZEO4NJ/atutqjyJ4siVnYCCJQAJCurAsTrbwW9JncLxmTmHkZPTnwZMf0Y8clQVONv/AMjamzErramhn4LMVg7JYwspLLYEgEDSo8blsCTFgSJbRMNrEjVjfpetkL7omuUckHU9tL9KLMbKO/ifKtBVr60K0B8KvsNtda4jjJXaHFLMcl1NmKjUr9elcMeQ4iNeF4OMNj8cFFsmd1tvkPdUHbua9zc8vBY+EmNw0PHe05YI1jEU0ku4NEoGn2EAnxrF4lcOCQYMYKzemly1vubp3NSEKpMYIBsLi3nas6+0TY7+pE+nj0qSO5VlFmBsBp1AoIi/YvQdh5mtinc3du1dfr8LX0ptLnsawtQEha8gP9pt0qFVB9LaAJFuNfCsOGeMyQQPHKsKjQmM3UadgaKFNskujWGtjrasl1QsDuujDXWuVCgt6hIdddCutqyI5UMbxswZCPuB8waWKIFVbV27k1dxsXrY9a2/xr50KIJtYXvT8pkY82TjxxFXSG11JIsx8r1i4efhZizJ9oU4fqxD5BXU3NQ+2Tm4/C8xIl4MafdHuFrliHBCW73amzcn3dwubmJGSkMeSrx32ggO8SsBfwven5PkPc0sWLOGWOLguIbIRG8HmkmU3/8AWpON4uDlOUysqSIRPk4q4quA4Z/UKs1gVBrLyWAR8qV5GUahSToL+VKVBlncXPgv1rVvp2rppQrQXNIlwnqtsV2/G5rE4BssYo5ZmhgzCD6fqqpdQ1jqp21JmY/svJ9xuVvg53FTRyqT2JRyjD91e3sn3J7S5L2pwTZ8Z5/meRMaBsbeDJCq7mZi40ttr2nzn/Ens7HbE47F/S+5PanCY0GOWKa4+WIkVQ7AEqxGtgKfDj/4o9wyY0w/yRZEaY8Sta29vUcDSuY9w+8ZcfE5zNgfE4f2/iSeqYfV/OSWQCxYrcBVB171Gh+9R00PUdQaWSbIVFcX2D+tH0xuPjV9tAdKBLXP9tKu4K4NwhGnzv417d5RZRbA5SKWdr/ik14iT4WJrDZpR6gRLte3UV7bXncv9JwEKFsPLkNsZswmwWZz+OnS/WuIf25yqcjyiyJ6f6EmRTHe7GRhooGvWis77XRSGIc9hresTjsckiNZXVUIDbgLBvkCa/3DJJJKobpe19R0ub3q0gWORTrGBYkeB8D5UR49D4152+H/AG9z/SmKqu6+jNqBbyoRsmyLMhKTKP8ApboWH7xR9s8xkGPmeKTbiTg/ZkRDRXB/ga/+ZncfgZ2O+2R48mU/dbp10uPKkgwOBwkhnGoxspAy31Ia5qd5yYZy3p4uITukkZtFVbaHU0uLJKJZsKO/IyJr/uJCGKKewRRY+Zppv8m+EFcUtZ1Rj38TbtTO7JIWNlI1BPn50UBDeLDp9Kv2oUKuWIHYDrUS/kt9Vc+dLB+q/Q5Cv6vD8sv5YmR23nvG/wCLD60nG+544eP5rCbZm4uRYoSNN8ZOjKaL4YxMnOlFseDFA3s3bpQ5Kdkm9wZaleJwwd0eIh0Mn/kBe3nUrjcZJZCciaU3Yu1yT8yaIVwVH3C3W/1ph1v/AD714AdK8vhehQ8ANBQZTtsbio48+KPJaAbY3cXZR4AnW3lTth48cchFle16knmmZ3c7txJJv5mmsbbulqJ8e/wv4fHyr+VedC/SjsvfS9a9LU1/9Cta0rX6fH//2Q=="

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      PictureBox1.Image = New Bitmap(New MemoryStream(Convert.FromBase64String(photo)))
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked, LinkLabel2.LinkClicked
      System.Diagnostics.Process.Start(CType(sender, LinkLabel).Text)
    End Sub
  End Class

#Region "Ÿ���� ��������"
  <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
  Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
        If disposing AndAlso components IsNot Nothing Then
          components.Dispose()
        End If
      Finally
        MyBase.Dispose(disposing)
      End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
      Me.PictureBox1 = New System.Windows.Forms.PictureBox
      Me.Label1 = New System.Windows.Forms.Label
      Me.Label2 = New System.Windows.Forms.Label
      Me.Label3 = New System.Windows.Forms.Label
      Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
      Me.LinkLabel2 = New System.Windows.Forms.LinkLabel
      Me.Button1 = New System.Windows.Forms.Button
      CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'PictureBox1
      '
      Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
      Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
      Me.PictureBox1.Name = "PictureBox1"
      Me.PictureBox1.Size = New System.Drawing.Size(100, 100)
      Me.PictureBox1.TabIndex = 0
      Me.PictureBox1.TabStop = False
      '
      'Label1
      '
      Me.Label1.AutoSize = True
      Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
      Me.Label1.Location = New System.Drawing.Point(118, 12)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(49, 13)
      Me.Label1.TabIndex = 1
      Me.Label1.Text = "Base64"
      '
      'Label2
      '
      Me.Label2.AutoSize = True
      Me.Label2.Location = New System.Drawing.Point(118, 35)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(126, 13)
      Me.Label2.TabIndex = 2
      Me.Label2.Text = "�����: Aleksey S Nemiro"
      '
      'Label3
      '
      Me.Label3.AutoSize = True
      Me.Label3.Location = New System.Drawing.Point(118, 48)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(61, 13)
      Me.Label3.TabIndex = 3
      Me.Label3.Text = "12.04.2008"
      '
      'LinkLabel1
      '
      Me.LinkLabel1.AutoSize = True
      Me.LinkLabel1.Location = New System.Drawing.Point(120, 70)
      Me.LinkLabel1.Name = "LinkLabel1"
      Me.LinkLabel1.Size = New System.Drawing.Size(76, 13)
      Me.LinkLabel1.TabIndex = 4
      Me.LinkLabel1.TabStop = True
      Me.LinkLabel1.Text = "http://kbyte.ru"
      '
      'LinkLabel2
      '
      Me.LinkLabel2.AutoSize = True
      Me.LinkLabel2.Location = New System.Drawing.Point(120, 83)
      Me.LinkLabel2.Name = "LinkLabel2"
      Me.LinkLabel2.Size = New System.Drawing.Size(120, 13)
      Me.LinkLabel2.TabIndex = 5
      Me.LinkLabel2.TabStop = True
      Me.LinkLabel2.Text = "http://aleksey.nemiro.ru"
      '
      'Button1
      '
      Me.Button1.Location = New System.Drawing.Point(328, 92)
      Me.Button1.Name = "Button1"
      Me.Button1.Size = New System.Drawing.Size(67, 20)
      Me.Button1.TabIndex = 6
      Me.Button1.Text = "Ok"
      Me.Button1.UseVisualStyleBackColor = True
      '
      'Form3
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(404, 121)
      Me.Controls.Add(Me.Button1)
      Me.Controls.Add(Me.LinkLabel2)
      Me.Controls.Add(Me.LinkLabel1)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.Label2)
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.PictureBox1)
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "Form3"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "� ���������..."
      CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)
      Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Button1 As System.Windows.Forms.Button
  End Class
#End Region
#End Region
End Class