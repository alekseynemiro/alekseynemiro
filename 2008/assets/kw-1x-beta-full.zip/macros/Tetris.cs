using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Data;
using System.Threading;
using System.IO;

/// <![CDATA[
/// <kbyteWorldMacros>
///   <name>������ ������ Tetris</name>
///   <version>1.0</version>
///   <author>������ ����</author>
///   <mail>tkz@uncnet.ru</mail>
///   <description>
///   � �������� �������� ��� �������� C# ��� ������ � ���� ����� ��������� C-���� ��� ���� Tetris. 
///   ������ ���� �������� C-��������� � C# � ������, �������� �� C � C#, �������, ��� �������� ��������� (� ����, �� ������� ����) ������� � ������ � �����������. 
///   ���-�� ����� ������� �� ������ ����� ������������ � ������� ��������������� ����� :). 
///   ��, ��� ������ string &lt;--&gt; char. 
///   ����� �� ��� ��������� �������, ��� ��� ������ �����������. 
///   � � �����, ��-�����, ����� ����������� � ��������� ����. 
///   ��, ����� ��� ���������, ��� ����������� ���������� (��������) ���������� � % �� ����� TaskManager'�. 
///   �� ������ ������� .NET � ����� ���� ������ ������� �� ����, ������ �����... :) 
///   </description>
/// </kbyteWorldMacros>
/// ]]>
public class KbyteWorldMacros
{
  #region ���� ��� ������������ Kbyte World Macros Creator v.1.0
  #region >> !�� ��������� ������ ���! <<
  /*
   * � ������ ���� ���������� 
   * ������ �� ��������� ������� � KbyteWorld.exe,
   * ����� KbyteWorld.exe � ������ ����� ����������������� 
   * ���� � ������.
   */
  private Kbyte.World.Macros _Macros;

  public KbyteWorldMacros(Kbyte.World.Macros m)
  {
    _Macros = m;
  }
  /*
   * ��� ��������� ������� � ���������� ������� � KbyteWorld.exe
   * ����������� ���������� _Macros
   */
  #endregion

  public Form MainForm;
  public Form KbyteWorldForm;

  /// <summary>
  /// ������ �������
  /// </summary>
  /// <param name="f">������ �� �������� ����� Kbyte World</param>
  public void Run(Form f)
  {
    KbyteWorldForm = f;
    MainForm = new Form1(this);
    MainForm.MdiParent = KbyteWorldForm;
    MainForm.Show();
    #region >> !�� ��������� ������ ���! <<
    /*
     * ������ ��� �������� ���������� � KbyteWorld.exe
     * � ���, ��� ������ ������� � ��������.
     */
    if (_Macros != null)
      _Macros.IsRun = true;
    #endregion
  }

  /// <summary>
  /// ���������� ������ �������
  /// </summary>
  public void Stop()
  {
    if (MainForm != null)
      MainForm.Close();

    #region >> !�� ��������� ������ ���! <<
    /*
     * ������ ��� �������� ���������� � KbyteWorld.exe
     * � ���, ��� ������ �������� ���� ������.
     */
    if (_Macros != null)
      _Macros.IsRun = false;
    #endregion
  }
  #endregion

  #region ...
  public struct block
  {
    public char[] pbyMask;
    public int iRange;
    public int iUpLine;
    public Color color;
    public block(string pm, int r, int l, Color c)
    {
      pbyMask = new char[100];
      pbyMask = pm.ToCharArray();
      iRange = r;
      iUpLine = l;
      color = c;
    }
  }

  public class Form1 : System.Windows.Forms.Form
  {
    private const int ITEM_NULL = 0xFF;
    private const int ITEM_EMPTY = ' ';
    private const int ITEM_FILL = '*';
    private const int FIGURES = 7;
    private const int WIDTH = 10;
    private const int HEIGHT = 17;
    private const int FREE = 15;
    private const int NEW = 16;
    private const int SUPERPOS = 17;
    private const int FALL = 18;
    private const int END_GAME = 20;
    private const int SET_CUBE = 22;
    private const int GET_CUBE = 23;

    private System.Windows.Forms.Timer tmr;
    private Random rand;

    private System.Windows.Forms.LinkLabel linkLabel1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ListView listView1;
    private System.Windows.Forms.ColumnHeader columnHeader1;
    private System.Windows.Forms.ColumnHeader columnHeader2;
    private System.Windows.Forms.ProgressBar progressBar1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.ListView listView2;
    private System.Windows.Forms.ColumnHeader columnHeader3;
    private System.Windows.Forms.ColumnHeader columnHeader4;
    private System.Windows.Forms.LinkLabel linkLabel2;
    private System.Windows.Forms.LinkLabel linkLabel3;
    private System.Windows.Forms.Label label3;
    private ShowNext showNext;

    private KbyteWorldMacros kwm;

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    Color[][] _COLOR_ = new Color[WIDTH + 4][];
    char[][] Glass = new char[WIDTH + 4][];
    char[][] OldGlass = new char[WIDTH + 4][];
    char[][] Temp = new char[WIDTH + 4][];

    public Form1(KbyteWorldMacros KWM)
    {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();
      kwm = KWM;
      tmr = new System.Windows.Forms.Timer();
      tmr.Tick += new EventHandler(TimerProc);
      tmr.Interval = 100;
      rand = new Random();
      for (int i = 0; i < WIDTH + 4; i++)
      {
        Glass[i] = new char[HEIGHT + 4];
        Temp[i] = new char[HEIGHT + 4];
        OldGlass[i] = new char[HEIGHT + 4];
        _COLOR_[i] = new Color[HEIGHT + 4];
      }

      this.showNext = new ShowNext(370, 250);
      this.Controls.AddRange(new System.Windows.Forms.Control[] { this.showNext });

      listView2.Focus();
      resetvars();
      tmr.Start();
      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    public void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (kwm != null)
        kwm.Stop();
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (components != null)
        {
          components.Dispose();
        }
      }
      tmr.Stop();
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "4", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "left")}, -1);
      System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "6", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "right")}, -1);
      System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "5", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "rotate")}, -1);
      System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "1", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "show next")}, -1);
      System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "3", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "grid on/off")}, -1);
      System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "8", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "speed up")}, -1);
      System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "2", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "speed down")}, -1);
      System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "0", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "drop")}, -1);
      System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "clock", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "00:00:00")}, -1);
      System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "count", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "0")}, -1);
      System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "score", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "0")}, -1);
      System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "max", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "0")}, -1);
      System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "key", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "\'1\'")}, -1);
      System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "pressed", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "0")}, -1);
      System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "level", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "10")}, -1);
      System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "cpu", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)))),
																																								 new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "0%")}, -1);
      this.linkLabel1 = new System.Windows.Forms.LinkLabel();
      this.label1 = new System.Windows.Forms.Label();
      this.listView1 = new System.Windows.Forms.ListView();
      this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
      this.progressBar1 = new System.Windows.Forms.ProgressBar();
      this.label2 = new System.Windows.Forms.Label();
      this.listView2 = new System.Windows.Forms.ListView();
      this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
      this.linkLabel2 = new System.Windows.Forms.LinkLabel();
      this.linkLabel3 = new System.Windows.Forms.LinkLabel();
      this.label3 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // linkLabel1
      // 
      this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.linkLabel1.Location = new System.Drawing.Point(464, 512);
      this.linkLabel1.Name = "linkLabel1";
      this.linkLabel1.Size = new System.Drawing.Size(32, 16);
      this.linkLabel1.TabIndex = 4;
      this.linkLabel1.TabStop = true;
      this.linkLabel1.Text = "Exit";
      this.linkLabel1.Enter += new System.EventHandler(this.linkLabel1_Enter);
      this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
      // 
      // label1
      // 
      this.label1.BackColor = System.Drawing.SystemColors.HotTrack;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.label1.ForeColor = System.Drawing.Color.White;
      this.label1.Location = new System.Drawing.Point(360, 304);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(136, 24);
      this.label1.TabIndex = 7;
      this.label1.Text = "Keymap";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // listView1
      // 
      this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2});
      this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
																					  listViewItem1,
																					  listViewItem2,
																					  listViewItem3,
																					  listViewItem4,
																					  listViewItem5,
																					  listViewItem6,
																					  listViewItem7,
																					  listViewItem8});
      this.listView1.Location = new System.Drawing.Point(360, 332);
      this.listView1.Name = "listView1";
      this.listView1.Size = new System.Drawing.Size(136, 168);
      this.listView1.TabIndex = 8;
      this.listView1.View = System.Windows.Forms.View.Details;
      this.listView1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.listView1_KeyPress);
      // 
      // columnHeader1
      // 
      this.columnHeader1.Text = "key";
      this.columnHeader1.Width = 36;
      // 
      // columnHeader2
      // 
      this.columnHeader2.Text = "value";
      this.columnHeader2.Width = 96;
      // 
      // progressBar1
      // 
      this.progressBar1.Location = new System.Drawing.Point(56, 504);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new System.Drawing.Size(288, 24);
      this.progressBar1.TabIndex = 9;
      // 
      // label2
      // 
      this.label2.BackColor = System.Drawing.SystemColors.HotTrack;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.label2.ForeColor = System.Drawing.Color.White;
      this.label2.Location = new System.Drawing.Point(360, 52);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(136, 24);
      this.label2.TabIndex = 10;
      this.label2.Text = "Statistics";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // listView2
      // 
      this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader3,
																						this.columnHeader4});
      this.listView2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
																					  listViewItem9,
																					  listViewItem10,
																					  listViewItem11,
																					  listViewItem12,
																					  listViewItem13,
																					  listViewItem14,
																					  listViewItem15,
																					  listViewItem16});
      this.listView2.Location = new System.Drawing.Point(360, 80);
      this.listView2.Name = "listView2";
      this.listView2.Size = new System.Drawing.Size(136, 168);
      this.listView2.TabIndex = 11;
      this.listView2.View = System.Windows.Forms.View.Details;
      this.listView2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.listView2_KeyPress);
      // 
      // columnHeader3
      // 
      this.columnHeader3.Text = "name";
      // 
      // columnHeader4
      // 
      this.columnHeader4.Text = "value";
      this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      this.columnHeader4.Width = 72;
      // 
      // linkLabel2
      // 
      this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.linkLabel2.Location = new System.Drawing.Point(408, 512);
      this.linkLabel2.Name = "linkLabel2";
      this.linkLabel2.Size = new System.Drawing.Size(48, 16);
      this.linkLabel2.TabIndex = 14;
      this.linkLabel2.TabStop = true;
      this.linkLabel2.Text = "About";
      this.linkLabel2.Enter += new System.EventHandler(this.linkLabel2_Enter);
      this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked_1);
      // 
      // linkLabel3
      // 
      this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.linkLabel3.Location = new System.Drawing.Point(360, 512);
      this.linkLabel3.Name = "linkLabel3";
      this.linkLabel3.Size = new System.Drawing.Size(36, 16);
      this.linkLabel3.TabIndex = 15;
      this.linkLabel3.TabStop = true;
      this.linkLabel3.Text = "New";
      this.linkLabel3.Click += new System.EventHandler(this.linkLabel3_Click);
      this.linkLabel3.Enter += new System.EventHandler(this.linkLabel3_Enter);
      // 
      // label3
      // 
      this.label3.BackColor = System.Drawing.Color.DarkBlue;
      this.label3.Font = new System.Drawing.Font("Tahoma", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.label3.ForeColor = System.Drawing.Color.White;
      this.label3.Location = new System.Drawing.Point(8, 8);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(488, 40);
      this.label3.TabIndex = 13;
      this.label3.Text = "Tetris CSharp (n) 2002 JeT";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.SystemColors.Info;
      this.ClientSize = new System.Drawing.Size(504, 534);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.linkLabel1,
																		  this.label1,
																		  this.listView1,
																		  this.progressBar1,
																		  this.label2,
																		  this.listView2,
																		  this.label3,
																		  this.linkLabel2,
																		  this.linkLabel3});
      this.Name = "Form1";
      this.Text = "TetrisCSharp - freeware (n) 2002";
      this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
      this.ResumeLayout(false);

    }
    #endregion

    private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
      tmr.Stop();
      DialogResult i = MessageBox.Show("Exit from Tetris CSharp?", "Tetris C#", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
      if (i == DialogResult.Yes)
        this.Close();
      else
        tmr.Enabled = true;
    }

    private void linkLabel2_LinkClicked_1(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
      MessageBox.Show("Tetris CSharp Version 0.99\n\nThis is a freeware product.\n\nNo rights reserved (2002).", "Tetris C#", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    block[] blocks = new block[]
		{
			new block("00  00   ", 3, 0, Color.Black), new block(" 0 000   ", 3, 0, Color.Black),
			new block("0  000   ", 3, 0, Color.Black), new block("  0000   ", 3, 0, Color.Black),
			new block(" 0000    ", 3, 0, Color.Black), new block("0000", 2, 0, Color.Black),
			new block("       0    0    0    0  ", 5, -1, Color.Black)
		};

    int iRange, iStatus, x, y;
    int score, curscore, fig, count, press, percent;

    int maxscore = 0, nextfig = 0;
    int level = 10, shownext = 1, grid = 0;
    char[] pbyMask = new char[100];
    Color color;

    private void putarea(int x, int y, char fl)
    {
      Point p1 = new Point(0, 0);
      Point p2 = new Point(20, 10);
      Graphics g = this.CreateGraphics();
      SolidBrush brush = new SolidBrush(Color.Black);
      LinearGradientBrush brush1 = new LinearGradientBrush(p1, p2, _COLOR_[x][y], Color.White);

      if (fl == System.Convert.ToChar(ITEM_FILL))
      {
        g.FillRectangle(brush, x * 25 + 75, y * 25 + 52, 24, 24);
        brush.Color = _COLOR_[x][y];
        g.FillRectangle(brush1, x * 25 + 75 + 1, y * 25 + 52 + 1, 22, 22);
      }
      else
      {
        brush.Color = Color.White;
        g.FillRectangle(brush, x * 25 + 75, y * 25 + 52, 24 + grid, 24 + grid);
      }
    }

    private void figure()
    {
      fig = nextfig;
      nextfig = rand.Next() % FIGURES;
      blocks[fig].pbyMask.CopyTo(pbyMask, 0);
      iRange = blocks[fig].iRange;
      y = blocks[fig].iUpLine;
      x = (WIDTH - iRange) / 2;
      color = blocks[fig].color;
    }

    private int check(int op)
    {
      for (int j = 0; j < iRange; j++)
      {
        for (int i = 0; i < iRange; i++)
        {
          if (pbyMask[i + j * iRange] != System.Convert.ToChar(ITEM_EMPTY))
          {
            switch (op)
            {
              case SET_CUBE:
                Glass[i + x + 2][j + y + 2] = System.Convert.ToChar(ITEM_FILL);
                _COLOR_[i + x][j + y] = color;
                break;
              case GET_CUBE:
                if (Glass[i + x + 2][j + y + 2] != System.Convert.ToChar(ITEM_EMPTY))
                  return SUPERPOS;
                break;
            }
          }
        }
      }
      return FREE;
    }

    private void show(int redraw)
    {
      int i, j, k, l = 0;

      Point p1 = new Point(0, 10);
      Point p2 = new Point(20, 0);
      Graphics g = this.CreateGraphics();
      SolidBrush brush = new SolidBrush(Color.Gray);
      LinearGradientBrush brush1 = new LinearGradientBrush(p1, p2, Color.MediumBlue, Color.Khaki);
      if (redraw != 0)
      {
        g.FillRectangle(brush1, 55, 52, 20, 425);
        g.FillRectangle(brush1, 325, 52, 20, 425);
        g.FillRectangle(brush1, 55, 477, 290, 20);
        if (grid == 0)
          g.FillRectangle(brush, 75, 52, 325 - 75, 425);
      }

      for (i = 0; i < WIDTH + 4; i++)
        Glass[i].CopyTo(Temp[i], 0);
      check(SET_CUBE);
      for (j = 0; j < HEIGHT; j++)
      {
        k = 0;
        for (i = 0; i < WIDTH; i++)
        {
          if (Glass[i + 2][j + 2] != System.Convert.ToChar(ITEM_EMPTY))
            k++;
          if (OldGlass[i + 2][j + 2] != Glass[i + 2][j + 2])
          {
            putarea(i, j, Glass[i + 2][j + 2]);
            OldGlass[i + 2][j + 2] = Glass[i + 2][j + 2];
          }
          else if (redraw != 0)
            putarea(i, j, Glass[i + 2][j + 2]);
          if ((l == 0) && (k > 4))
          {
            percent = 100 - (j * 6);
            l = 1;
          }
        }
      }
      for (i = 0; i < WIDTH + 4; i++)
        Temp[i].CopyTo(Glass[i], 0);
      progressBar1.Value = percent;
    }

    private void turn()
    {
      int off, pos, i1, i2, i3;
      char c;

      int range = iRange - 1;
      if ((iRange & 1) != 0)
      {
        for (off = 0; off < range / 2; off++)
        {
          for (pos = 0; pos < range - off * 2; pos++)
          {
            i1 = pos + off;
            i2 = range - off;
            i3 = range - pos - off;

            c = pbyMask[off + i1 * iRange];
            pbyMask[off + i1 * iRange] = pbyMask[i1 + i2 * iRange];
            pbyMask[i1 + i2 * iRange] = pbyMask[i2 + i3 * iRange];
            pbyMask[i2 + i3 * iRange] = pbyMask[i3 + off * iRange];
            pbyMask[i3 + off * iRange] = c;
          }
        }
      }
    }

    private void doleft()
    {
      x--;
      if (check(GET_CUBE) == SUPERPOS)
        x++;
      show(0);
    }

    private void doright()
    {
      x++;
      if (check(GET_CUBE) == SUPERPOS)
        x--;
      show(0);
    }

    private void doturn()
    {
      turn();
      turn();
      turn();
      if (check(GET_CUBE) == SUPERPOS)
        turn();
      show(0);
    }

    private int next()
    {
      int i, j, n, k;

      switch (iStatus)
      {
        case FALL:
          y++;
          if (check(GET_CUBE) == SUPERPOS)
          {
            y--;
            check(SET_CUBE);
            score += (550 - level * 50);
            for (n = j = HEIGHT + 1; j > 1; j--)
            {
              for (i = k = 0; i < WIDTH; i++)
              {
                Glass[i + 2][n] = Glass[i + 2][j];
                if (Glass[i + 2][n] == System.Convert.ToChar(ITEM_EMPTY))
                  k++;
                if (n != j)
                  Glass[i + 2][j] = System.Convert.ToChar(ITEM_EMPTY);
              }
              if (k != 0)
                n--;
            }
            goto case NEW;
          }
          else
          {
            show(0);
            break;
          }
        case NEW:
          figure();
          count++;
          score += (110 - level * 10);
          if (check(GET_CUBE) == SUPERPOS)
          {
            iStatus = END_GAME;
            break;
          }
          show(0);
          iStatus = FALL;
          break;
      }
      return iStatus;
    }

    void quickfall()
    {
      if (y < 0)
        next();
      next();
      while (y >= 1)
        next();
    }

    private void resetvars()
    {
      if (maxscore < score)
        maxscore = score;
      curscore = score = count = press = percent = 0;
      iStatus = NEW;
      nextfig = rand.Next() % FIGURES;
      for (int i = 0; i < FIGURES; i++)
        blocks[i].color = Color.FromArgb(rand.Next() % 256, rand.Next() % 256, rand.Next() % 256);
      for (int j = 0; j < HEIGHT + 4; j++)
        for (int i = 0; i < WIDTH + 4; i++)
        {
          _COLOR_[i][j] = Color.Black;
          Glass[i][j] = OldGlass[i][j] = System.Convert.ToChar(ITEM_NULL);
          if (((i > 1) && (i < WIDTH + 2)) && ((j > 1) && (j < HEIGHT + 2)))
            Glass[i][j] = System.Convert.ToChar(ITEM_EMPTY);
        }
      progressBar1.Value = percent;
    }

    private static int fl_next1 = 0, ii = 0, old_s = -1;
    private void TimerProc(Object myObject, EventArgs myEventArgs)
    {
      if (fl_next1 == 0)
      {
        fl_next1++;
        DateTime t = DateTime.Now;
        int s = t.Second;
        if (s != old_s)
        {
          int l = rand.Next() % 100;
          string buf = System.Convert.ToString(t.Hour) + ":" + System.Convert.ToString(t.Minute) + ":" + System.Convert.ToString(t.Second);
          listView2.Items[0].SubItems[1].Text = buf;
          listView2.Items[1].SubItems[1].Text = System.Convert.ToString(count);
          listView2.Items[2].SubItems[1].Text = System.Convert.ToString(score);
          listView2.Items[3].SubItems[1].Text = System.Convert.ToString(maxscore);
          listView2.Items[7].SubItems[1].Text = System.Convert.ToString(l);
          old_s = s;
        }
        if (((score - curscore) > (1000 * level)) && (level > 1))
        {
          curscore = score;
          level--;
        }
        if (shownext != 0 && (nextfig != fig))
          showNext.Next(nextfig, blocks[nextfig].color);
        if (ii++ >= level)
        {
          ii = 0;
          if (next() == END_GAME)
          {
            progressBar1.Value = 100;
            tmr.Stop();
            MessageBox.Show("End of this attempt...", "Tetris C#", MessageBoxButtons.OK, MessageBoxIcon.Information);
            resetvars();
            tmr.Enabled = true;
          }
        }
        fl_next1--;
      }
    }

    private void Form1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
    {
      char ch = e.KeyChar;

      switch (ch)
      {
        case ' ':
          goto case '0';
        case '0':
          quickfall();
          break;
        case '1':
          shownext ^= 1;
          fig = -1;
          showNext.Next(fig, Color.Black);
          break;
        case '2':
          if (level < 10)
            level++;
          break;
        case (char)0x0D:
          goto case '3';
        case '3':
          grid ^= 1;
          show(1);
          break;
        case '4':
          doleft();
          break;
        case '5':
          doturn();
          break;
        case '6':
          doright();
          break;
        case '8':
          if (level > 1)
            level--;
          break;
        case (char)0x1B:
          tmr.Stop();
          DialogResult i = MessageBox.Show("Exit from Tetris CSharp?", "Tetris C#", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
          if (i == DialogResult.Yes)
            Application.Exit();
          tmr.Enabled = true;
          break;
        case '.':
          resetvars();
          break;
      }
      listView2.Items[4].SubItems[1].Text = "'" + System.Convert.ToString(ch) + "'";
      listView2.Items[5].SubItems[1].Text = System.Convert.ToString(++press);
      listView2.Items[6].SubItems[1].Text = System.Convert.ToString(level);
      e.Handled = true;
    }

    private void listView2_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
    {
      Form1_KeyPress(sender, e);
    }

    private void listView1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
    {
      Form1_KeyPress(sender, e);
    }

    private void linkLabel1_Enter(object sender, System.EventArgs e)
    {
      listView2.Focus();
    }

    private void linkLabel2_Enter(object sender, System.EventArgs e)
    {
      listView2.Focus();
    }

    private void linkLabel3_Enter(object sender, System.EventArgs e)
    {
      listView2.Focus();
    }

    private void linkLabel3_Click(object sender, System.EventArgs e)
    {
      tmr.Stop();
      DialogResult i = MessageBox.Show("Cancel current game?", "Tetris C#", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
      tmr.Enabled = true;
      if (i == DialogResult.Yes)
        resetvars();
    }

    private void syslog(string buf)
    {
      DateTime t = DateTime.Now;
      string path = "C:\\TEMP\\1111.txt";
      string tmp = System.Convert.ToString(t.Hour) + ":" + System.Convert.ToString(t.Minute) + ":" + System.Convert.ToString(t.Second) + "." + System.Convert.ToString(t.Millisecond) + "\t";

      tmp += buf;
      tmp += "\n";
      ASCIIEncoding AE = new ASCIIEncoding();
      byte[] bt = AE.GetBytes(tmp);
      FileStream f = File.Open(path, FileMode.Append, FileAccess.Write);
      if (f != null)
      {
        f.BeginWrite(bt, 0, bt.Length, null, null);
        f.Close();
      }
    }

    private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
    {
      Point p1 = new Point(0, 10);
      Point p2 = new Point(20, 0);
      SolidBrush brush = new SolidBrush(Color.Gray);
      LinearGradientBrush brush1 = new LinearGradientBrush(p1, p2, Color.MediumBlue, Color.Khaki);
      e.Graphics.FillRectangle(brush1, 55, 52, 20, 425);
      e.Graphics.FillRectangle(brush1, 325, 52, 20, 425);
      e.Graphics.FillRectangle(brush1, 55, 477, 290, 20);
      if (grid == 0)
        e.Graphics.FillRectangle(brush, 75, 52, 325 - 75, 425);
      int x = 380;
      int y = 498;
      String drawStr = "Jerry Trusov (JeT)";
      Font drawFont = new Font("Arial", 8);
      brush.Color = Color.Khaki;
      e.Graphics.DrawString(drawStr, drawFont, brush, x, y);
    }
  }
  #endregion
  #region ...
  public class ShowNext : System.Windows.Forms.UserControl
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>

    private string[] draw =
		{
			"##   ## 10", " #  ### 10", "#   ### 10", 
			"  # ### 10", " ## ##  10", " ##  ## 00",
			"####    01"
		};
    private int curfig = -1;

    private System.ComponentModel.Container components = null;

    public ShowNext()
    {
      // This call is required by the Windows.Forms Form Designer.
      InitializeComponent();

      // TODO: Add any initialization after the InitForm call
    }

    public ShowNext(int X, int Y)
    {
      // This call is required by the Windows.Forms Form Designer.
      InitializeComponent();
      this.Left = X;
      this.Top = Y;

      // TODO: Add any initialization after the InitForm call
    }

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (components != null)
        {
          components.Dispose();
        }
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code
    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      // 
      // ShowNext
      // 
      this.BackColor = System.Drawing.Color.Goldenrod;
      this.Name = "ShowNext";
      this.Size = new System.Drawing.Size(114, 53);
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.ShowNext_Paint);

    }
    #endregion

    public void Next(int fig, Color color)
    {
      if (fig != curfig)
      {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(20, 10);
        Graphics g = this.CreateGraphics();
        SolidBrush brush = new SolidBrush(Color.Khaki);
        LinearGradientBrush brush1 = new LinearGradientBrush(p1, p2, color, Color.White);
        g.FillRectangle(brush, 2, 2, 111, 51);

        if (fig != -1)
        {
          int dx = (draw[fig][8] == '1' ? 12 : 2);
          int dy = (draw[fig][9] == '1' ? 12 : 2);
          for (int i = 0; i < 8; i++)
          {
            int x = (i % 4) * 25 + 6 + dx;
            int y = (i / 4) * 25 + 1 + dy;
            if (draw[fig][i] == '#')
            {
              brush.Color = Color.Black;
              g.FillRectangle(brush, x, y, 24, 24);
              g.FillRectangle(brush1, x + 1, y + 1, 22, 22);
            }
          }
        }
        curfig = fig;
      }
    }

    private void ShowNext_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
    {
      Pen pen = new Pen(Color.WhiteSmoke, 2);
      e.Graphics.DrawLine(pen, 113, 0, 113, 53);
    }
  }
  #endregion
}