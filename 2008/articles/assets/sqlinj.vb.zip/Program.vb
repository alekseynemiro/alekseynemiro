Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.IO
Imports Microsoft.VisualBasic

'
' * Пример к статье "Автоматизация поиска SQL Injection"
' * Автор: Немиро Алексей, 12.05.2008
' * http://aleksey.nemiro.ru
' * http://kbyte.ru
' 
Namespace SqlInjectionSearch

  Public Class Program

    Private Shared _taskUrls As New List(Of String)() ' очередь адресов
    Private Shared _analUrls As New List(Of String)() ' адреса для анализа

    Public Shared Sub Main(ByVal args As String())
      Dim myWeb As New System.Net.WebClient()
      Dim myReg As New System.Text.RegularExpressions.Regex("<a(\s*)href=""/ru/Private/Profile.aspx\?uid=(?<kuid>\d+)"">(?<user_name>[^\x3C]+)</a>")
      Dim s As String = myWeb.DownloadString("http://kbyte.ru/ru/Forums/Show.aspx?id=10580")
      For Each m As System.Text.RegularExpressions.Match In myReg.Matches(s)
        MsgBox(m.Groups("user_name").Value)
      Next

      _taskUrls.Add("http://www.diluch.ru/content/default.asp?id_host_content=675") ' << добавьте адреса для сканирования
      Process() ' запуск процесса сканирования
      Console.WriteLine("ok")
      Console.ReadKey()
    End Sub

    ''' <summary>
    ''' фукнция выполняет GET-запрос и возвращает полученные данные
    ''' </summary>
    ''' <param name="url">Адрес, данные с котрого нужно получить</param>
    Private Shared Function ExecuteHTTPGetRequest(ByVal url As String) As String

      Try
        ' делаем запрос и возвращаем ответ
        Dim req As HttpWebRequest = DirectCast(HttpWebRequest.Create(url), HttpWebRequest)
        Dim rsp As HttpWebResponse = DirectCast(req.GetResponse(), HttpWebResponse)
        Using sr As New StreamReader(rsp.GetResponseStream(), Encoding.GetEncoding(1251))
          Return sr.ReadToEnd()
        End Using
      Catch ex As WebException
        If ex.Status = WebExceptionStatus.ProtocolError AndAlso ex.Message.Contains("500") Then
          ' если ошибка сервера, получаем ее описание
          Using sr As New StreamReader(ex.Response.GetResponseStream(), Encoding.GetEncoding(1251))
            Return sr.ReadToEnd()
          End Using
        End If
      End Try
      Return String.Empty ' другая ошибка
    End Function

    ''' <summary>
    ''' Процедура производит поиск адресов страниц, и фильтрует их
    ''' </summary>
    ''' <param name="host">Хост, для фильтрации адресов</param>
    ''' <param name="source">Данные, полученные с сервера</param>
    Private Shared Sub SearchUrls(ByVal host As String, ByVal source As String)
      Dim rgx As New Regex("href\s*=\s*([\x22\x27]{0,1})(?<link>[^\s\n\x22\x27\x3E]*)")
      Dim mtchs As MatchCollection = rgx.Matches(source)
      If mtchs Is Nothing OrElse mtchs.Count <= 0 Then Return ' ничего не найдено, выходим
      For Each m As Match In mtchs
        Dim newUrl As String = m.Groups("link").Value
        ' если это E-Mail или JavaScript, то пропускаем его
        If Not newUrl.ToLower().StartsWith("mailto:") AndAlso Not newUrl.ToLower().StartsWith("javascript:") Then
          If Not New Regex("[a-zA-Z]+:\/\/").IsMatch(newUrl) Then
            ' это относительный путь, делаем из него обычную ссылку
            Dim p As String = newUrl, q As String = String.Empty
            If Not newUrl.IndexOf("?") = -1 Then
              p = newUrl.Substring(0, newUrl.IndexOf("?"))
              q = newUrl.Substring(newUrl.LastIndexOf("?"), newUrl.Length - newUrl.LastIndexOf("?"))
            End If
            newUrl = New UriBuilder("http", host, 80, p, q).Uri.ToString()
          End If
          Dim isNew As Boolean = True
          ' проверка хоста
          ' если данная фишка нужна, уберите комментарий
          isNew = (New Uri(newUrl).Host.ToLower() = host)
          ' проверка, может такая ссылка уже есть в списке заданий
          If isNew AndAlso _taskUrls.IndexOf(newUrl) = -1 Then
            ' добавляем адрес в список заданий
            _taskUrls.Add(newUrl)
          End If
          'If isNew AndAlso Not newUrl.IndexOf("?") = -1 Then
          ' если у адреса есть параметры, добавляем в список для поиска SQL Injection
          If isNew Then
            For Each u As String In _analUrls
              If New Uri(u).LocalPath = New Uri(newUrl).LocalPath Then
                ' такой уже есть, выходим
                isNew = False
                Exit For
              End If
            Next
            If isNew Then
              _analUrls.Add(newUrl)
            End If
          End If
        End If
        'End If
      Next
    End Sub

    ''' <summary>
    ''' Процедура выполняет "сканирование Интернета" :)
    ''' </summary>
    Private Shared Sub Process()
      If _taskUrls Is Nothing OrElse _taskUrls.Count <= 0 Then
        Console.WriteLine("Адреса для сканирования не найдены.")
        Return
      End If
      For i As Integer = 0 To _taskUrls.Count - 1
        ' этап первый, сбор адресов  
        SearchUrls(New Uri(_taskUrls(i)).Host, ExecuteHTTPGetRequest(_taskUrls(i)))
        If i > Integer.MaxValue Then Exit For ' сканируем только 50 страниц
      Next
      ' этап второй, попытка найти уязвимости на страницах
      Console.BackgroundColor = ConsoleColor.Black
      Console.WriteLine("Интернет просканирован. Найдено ссылок: {0}", _analUrls.Count)
      ' слова и сочетания слов, которые встречаются в сообщениях об ошибках при работы с БД
      Dim errorMessages As String() = New String() { _
      "sql syntax", "sql error", "ole db error", "incorrect syntax", "unclosed quotation mark", "sql server error", _
      "microsoft jet database engine error", "'microsoft.jet.oledb.4.0' reported an error", "reported an error", "provider error", "oracle database error", "database error", _
      "db error", "syntax error in string in query expression", "ошибка синтаксиса", "синтаксическая ошибка", "ошибка бд", "ошибочный запрос", _
      "ошибка доступа к бд" _
      }
      For Each u As String In _analUrls
        ' особо фантазировать не будем, просто вляпаем одинарную кавычку сразу после знака равно
        Dim s As String = ExecuteHTTPGetRequest(u.Replace("=", "='"))
        ' с надеждой, ищем сообщение об ошибке из словаря
        Dim sqlinj As Boolean = False
        For Each e As String In errorMessages
          ' если что-то найдено, ставим отметку
          If s.IndexOf(e, StringComparison.OrdinalIgnoreCase) <> -1 Then
            sqlinj = True
            Exit For
          End If
        Next
        If sqlinj Then
          Console.BackgroundColor = ConsoleColor.Red
        Else
          Console.BackgroundColor = ConsoleColor.Black
        End If
        Console.WriteLine("Анализ ссылки {0}", u + (IIf(sqlinj, " >>>>> SQL Injection! <<<<<", "").ToString()))
      Next
    End Sub
  End Class

End Namespace
