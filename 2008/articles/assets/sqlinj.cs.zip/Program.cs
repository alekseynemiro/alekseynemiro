﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Text.RegularExpressions;
using System.IO;

/*
 * Пример к статье "Автоматизация поиска SQL Injection"
 * Автор: Немиро Алексей, 12.05.2008
 * http://aleksey.nemiro.ru
 * http://kbyte.ru
 */

namespace SqlInjectionSearch
{
  class Program
  {
    static List<string> _taskUrls = new List<string>(); // очередь адресов
    static List<string> _analUrls = new List<string>(); // адреса для анализа

    static void Main(string[] args)
    {
      _taskUrls.Add("http://rcb.ru/"); // << добавьте адреса для сканирования
      Process(); // запуск процесса сканирования
      Console.ReadKey();
    }

    /// <summary>
    /// фукнция выполняет GET-запрос и возвращает полученные данные
    /// </summary>
    /// <param name="url">Адрес, данные с котрого нужно получить</param>
    static string ExecuteHTTPGetRequest(string url)
    {
      try
      { // делаем запрос и возвращаем ответ
        HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(url);
        HttpWebResponse rsp = (HttpWebResponse)req.GetResponse();
        using (StreamReader sr = new StreamReader(rsp.GetResponseStream(), Encoding.GetEncoding(1251)))
        {
          return sr.ReadToEnd();
        }
      }
      catch (WebException ex)
      {
        if (ex.Status == WebExceptionStatus.ProtocolError && ex.Message.Contains("500"))
        { // если ошибка сервера, получаем ее описание
          using (StreamReader sr = new StreamReader(ex.Response.GetResponseStream(), Encoding.GetEncoding(1251)))
          {
            return sr.ReadToEnd();
          }
        }
      }
      return string.Empty; // другая ошибка
    }

    /// <summary>
    /// Процедура производит поиск адресов страниц, и фильтрует их
    /// </summary>
    /// <param name="host">Хост, для фильтрации адресов</param>
    /// <param name="source">Данные, полученные с сервера</param>
    static void SearchUrls(string host, string source)
    {
      Regex rgx = new Regex(@"href\s*=\s*([\x22\x27]{0,1})(?<link>[^\s\n\x22\x27\x3E]*)");
      MatchCollection mtchs = rgx.Matches(source);
      if (mtchs == null || mtchs.Count <= 0) return; // ничего не найдено, выходим
      foreach (Match m in mtchs)
      {
        string newUrl = m.Groups["link"].Value;
        // если это E-Mail или JavaScript, то пропускаем его
        if (!newUrl.ToLower().StartsWith("mailto:") && !newUrl.ToLower().StartsWith("javascript:"))
        { 
          if (!new Regex(@"[a-zA-Z]+:\/\/").IsMatch(newUrl))
          { // это относительный путь, делаем из него обычную ссылку
            string p = newUrl.IndexOf("?") != -1 ? newUrl.Substring(0, newUrl.IndexOf("?")) : newUrl;
            string q = newUrl.LastIndexOf("?") != -1 ? newUrl.Substring(newUrl.LastIndexOf("?"), newUrl.Length - newUrl.LastIndexOf("?")) : string.Empty;
            newUrl = new UriBuilder("http", host, 80, p, q).Uri.ToString();           
          }
          bool isNew = true;
          // проверка хоста
          /* если данная фишка нужна, уберите комментарий
           isNew = (new Uri(newUrl).Host.ToLower() == host);
          */
          // проверка, может такая ссылка уже есть в списке заданий
          if (isNew && _taskUrls.IndexOf(newUrl) == -1)
          { // добавляем адрес в список заданий
            _taskUrls.Add(newUrl);
          }
          if (isNew && newUrl.IndexOf("?") != -1)
          { // если у адреса есть параметры, добавляем в список для поиска SQL Injection
            isNew = true;
            foreach (string u in _analUrls)
            {
              if (new Uri(u).LocalPath == new Uri(newUrl).LocalPath)
              { // такой уже есть, выходим
                isNew = false;
                break;
              }
            }
            if (isNew) _analUrls.Add(newUrl);
          }
        }
      }
    }

    /// <summary>
    /// Процедура выполняет "сканирование Интернета" :)
    /// </summary>
    static void Process()
    {
      if (_taskUrls == null || _taskUrls.Count <= 0)
      {
        Console.WriteLine("Адреса для сканирования не найдены.");
        return;
      }
      // этап первый, сбор адресов  
      for (int i = 0; i <= _taskUrls.Count - 1; i++)
      {
        SearchUrls(new Uri(_taskUrls[i]).Host, ExecuteHTTPGetRequest(_taskUrls[i]));
        if (i > 49) break; // сканируем только 50 страниц
      }
      // этап второй, попытка найти уязвимости на страницах
      Console.BackgroundColor = ConsoleColor.Black;
      Console.WriteLine("Интернет просканирован. Найдено ссылок: {0}", _analUrls.Count);
      // слова и сочетания слов, которые встречаются в сообщениях об ошибках при работы с БД
      string[] errorMessages  = new string[] {
      "sql syntax", "sql error",
      "ole db error", "incorrect syntax", "unclosed quotation mark",
      "sql server error", "microsoft jet database engine error", "'microsoft.jet.oledb.4.0' reported an error", "reported an error",
      "provider error", "oracle database error", "database error", "db error", "syntax error in string in query expression",
      "ошибка синтаксиса", "синтаксическая ошибка", 
      "ошибка бд", "ошибочный запрос", "ошибка доступа к бд"};
      foreach (string u in _analUrls)
      {
        // особо фантазировать не будем, просто вляпаем одинарную кавычку сразу после знака равно
        string s = ExecuteHTTPGetRequest(u.Replace("=", "='"));
        // с надеждой, ищем сообщение об ошибке из словаря
        bool sqlinj = false;
        foreach (string e in errorMessages)
        {
          // если что-то найдено, ставим отметку
          if (s.IndexOf(e, StringComparison.OrdinalIgnoreCase) != -1)
          {
            sqlinj = true;
            break;
          }
        }
        if (sqlinj) { Console.BackgroundColor = ConsoleColor.Red; } else { Console.BackgroundColor = ConsoleColor.Black; }
        Console.WriteLine("Анализ ссылки {0}", u + (sqlinj ? " >>>>> SQL Injection! <<<<<" : ""));
      }
    }
  }
}
