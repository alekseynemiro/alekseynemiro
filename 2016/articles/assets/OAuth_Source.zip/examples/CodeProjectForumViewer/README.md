﻿This is a sample application for **CodeProject**.

![CodeProject application](preview.png)

This application allows you to view messages of the **CodeProject** forums.

This application **Windows Forms**.
The source code is written in **C#**.

The application is licensed under the **Apache License Version 2.0**.