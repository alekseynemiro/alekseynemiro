This is the source code of the demo site:
http://demo-oauth.nemiro.net

Configuration of **OAuth** applications located in the **web.config** file.

For security, the secret keys have not been published.
If you want to use this website for their own needs, you should specify your own keys.