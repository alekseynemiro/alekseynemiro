﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Управление общими сведениями о сборке осуществляется с помощью 
' набора атрибутов. Измените значения этих атрибутов для изменения сведений,
' общие сведения об этой сборке.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("Test.VB.AspWebForms")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Aleksey Nemiro")> 
<Assembly: AssemblyProduct("Test.VB.AspWebForms")> 
<Assembly: AssemblyCopyright("Copyright © Aleksey Nemiro, 2014")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'Следующий GUID служит для идентификации библиотеки типов, если этот проект видим для COM
<Assembly: Guid("1471283e-debf-4d5f-a2c5-9d4ae9af63b6")> 

' Сведения о версии сборки состоят из указанных ниже четырех значений:
'
'      Основной номер версии
'      Дополнительный номер версии 
'      Номер сборки
'      Редакция
'
' You can specify all the values or you can default the Build and Revision Numbers 
' используя "*", как показано ниже:
' <Сборка: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
