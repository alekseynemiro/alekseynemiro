﻿Public Class DataColumnAttribute
  Inherits Attribute

  Private _ColumnName As String = String.Empty
  Private _Log As Boolean = False
  Private _PrimaryKey As Boolean = False
  Private _SqlDataType As SqlDbType = SqlDbType.Variant

  ''' <summary>
  ''' Название колонки в базе данных
  ''' </summary>
  Public ReadOnly Property ColumnName As String
    Get
      Return _ColumnName
    End Get
  End Property

  ''' <summary>
  ''' Тип данных
  ''' </summary>
  Public ReadOnly Property SqlDataType As SqlDbType
    Get
      Return _SqlDataType
    End Get
  End Property

  ''' <summary>
  ''' Флаг указывает на то, что колонка является PrimaryKey
  ''' </summary>
  Public ReadOnly Property PrimaryKey As Boolean
    Get
      Return _PrimaryKey
    End Get
  End Property

  ''' <summary>
  ''' Флаг указывает на то, что требуется отслеживать изменения и записывать в журнал
  ''' </summary>
  Public ReadOnly Property Log As Boolean
    Get
      Return _Log
    End Get
  End Property

  ''' <summary>
  ''' Создает атрибут для свойства воплащающего в себе поле таблицы базы данных
  ''' </summary>
  ''' <param name="columnName">Имя колонки в бд</param>
  ''' <param name="sqlDataType">Тип данных</param>
  ''' <param name="primaryKey">Флаг указывает на то, что колонка является PrimaryKey. True может иметь только одна колонка</param>
  ''' <param name="log">Флаг указывает на то, что требуется отслеживать изменения и записывать в журнал</param>
  Public Sub New(ByVal columnName As String, ByVal sqlDataType As SqlDbType, ByVal primaryKey As Boolean, ByVal log As Boolean)
    _ColumnName = columnName
    _SqlDataType = sqlDataType
    _Log = log
    _PrimaryKey = primaryKey
  End Sub

End Class