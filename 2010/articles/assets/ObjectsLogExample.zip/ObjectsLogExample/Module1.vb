﻿'**************************************************************************
'Пример к статье: Ведение журнала изменений объектов в .NET
'Автор: Алексей Немиро <http://aleksey.nemiro.ru>
'Специально для проекта Kbyte.Ru <http://kbyte.ru>
'Copyright © Aleksey S Nemiro, 2010
'**************************************************************************
Module Module1

  'строка соединения с базой данных
  'ВНИМАНИЕ! УКАЖИТЕ ЗДЕСЬ ВАШУ СТРОКУ СОЕДИНЕНИЯ!
  Public _ConnectionString As String = "Data Source=BOOK-2008\MSSMLBIZ;Initial Catalog=test;Trusted_Connection=True;"

  Sub Main()
    Console.WriteLine("Пример к статье: Ведение журнала изменений объектов в .NET")
    Console.WriteLine("Автор: Алексей Немиро <http://aleksey.nemiro.ru>")
    Console.WriteLine("Специально для проекта Kbyte.Ru <http://kbyte.ru>")
    Console.WriteLine("Copyright © Aleksey S Nemiro, 2010")
    Console.WriteLine("----------------------------------------------------------")
    Console.WriteLine()
    Console.WriteLine("Давайте проверим как все это работает.")
n:
    Console.WriteLine("Что вы хотите сделать?")
    Console.WriteLine("1 - создать нового пользователя;")
    Console.WriteLine("2 - загрузить данные пользователя;")
    Console.WriteLine("3 - создать компьютер;")
    Console.WriteLine("4 - загрузить данные компьютера;")
    Console.WriteLine("5 - заврешить работу программы;")
    Console.WriteLine("Введите число нужного действия:")
    Select Case Val(Console.ReadLine())
      Case 1
        Dim u As New Users()
        Console.WriteLine("Отлично! Давайте создадим нового пользователя!")
        Console.WriteLine("Введите имя:")
        u.first_name = Console.ReadLine()
        Console.WriteLine("Введите фамилию:")
        u.last_name = Console.ReadLine()
        Console.WriteLine("Введите пол:")
        u.sex = Console.ReadLine()
        Console.WriteLine("Введите возвраст:")
        u.age = Val(Console.ReadLine())
        u.Save()
        Console.WriteLine("Пользователь успешно создан! ID = {0}", u.id)
        Console.WriteLine("Используйте ID = {0}, чтобы загрузить и вывести данные в консоль.", u.id)
        Cont()
        GoTo n

      Case 2
        Console.WriteLine("Надеюсь, вы помните ID пользователя, которого нужно загрузить?")
        Console.WriteLine("Введите ID пользователя:")
        Dim u As New Users(Val(Console.ReadLine()))
        If u Is Nothing OrElse u.id <= 0 Then
          Console.WriteLine("Пользователь не найден.")
          Cont()
          GoTo n
        End If

        Console.WriteLine("Пользователь ID: {0}", u.id)
        Console.WriteLine("Имя            : {0}", u.first_name)
        Console.WriteLine("Фамилия        : {0}", u.last_name)
        Console.WriteLine("Пол            : {0}", u.sex)
        Console.WriteLine("Возраст        : {0}", u.age)
        Cont()
        GoTo n

      Case 3
        Dim c As New Computers()
        Console.WriteLine("Отлично! Давайте создадим новый компьютер!")
        Console.WriteLine("Введите название процессора:")
        c.cpu = Console.ReadLine()
        Console.WriteLine("Введите название операционной системы:")
        c.os = Console.ReadLine()
        Console.WriteLine("Введите ID пользователя (опционально):")
        c.user_id = Val(Console.ReadLine())
        c.Save()
        Console.WriteLine("Компьютер успешно создан! ID = {0}", c.id)
        Console.WriteLine("Используйте ID = {0}, чтобы загрузить и вывести данные в консоль.", c.id)
        Cont()
        GoTo n

      Case 4
        Console.WriteLine("Надеюсь, вы помните ID компьютера, которого нужно загрузить? :P")
        Console.WriteLine("Введите ID компьютера:")
        Dim c As New Computers(Console.ReadLine())
        If c Is Nothing OrElse c.id = Guid.Empty Then
          Console.WriteLine("Компьютер не найден.")
          Cont()
          GoTo n
        End If
        If c.user_id > 0 Then
          Console.WriteLine("Пользователь        : {0} {1}", c.User.first_name, c.User.last_name)
        End If
        Console.WriteLine("Процессор           : {0}", c.cpu)
        Console.WriteLine("Операционная система: {0}", c.os)
        Cont()
        GoTo n

      Case 5
        Return

      Case Else
        Console.WriteLine("Неизвестная команда.")
        Cont()
        GoTo n
    End Select
  End Sub

  Private Sub Cont()
    Console.WriteLine("Для продолжения нажмите на любую клавишу.")
    Console.ReadKey()
    Console.Clear()
  End Sub

End Module
