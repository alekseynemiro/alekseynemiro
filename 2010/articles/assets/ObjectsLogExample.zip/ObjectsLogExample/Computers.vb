﻿
<DataTableAttribute("computers")> _
Public Class Computers
  Inherits DataObject

  Private _id As Guid = Guid.Empty
  Private _user_id As Integer = 0
  Private _cpu As String = String.Empty
  Private _os As String = String.Empty

  <DataColumnAttribute("id", SqlDbType.UniqueIdentifier, True, False)> _
  Public Property id() As Guid
    Get
      Return _id
    End Get
    Set(ByVal value As Guid)
      _id = value
    End Set
  End Property

  <DataColumnAttribute("user_id", SqlDbType.Int, False, False)> _
  Public Property user_id() As Integer
    Get
      Return _user_id
    End Get
    Set(ByVal value As Integer)
      _user_id = value
    End Set
  End Property

  <DataColumnAttribute("cpu", SqlDbType.NVarChar, False, False)> _
  Public Property cpu() As String
    Get
      Return _cpu
    End Get
    Set(ByVal value As String)
      _cpu = value
    End Set
  End Property

  <DataColumnAttribute("os", SqlDbType.NVarChar, False, True)> _
  Public Property os() As String
    Get
      Return _os
    End Get
    Set(ByVal value As String)
      _os = value
    End Set
  End Property

  Private _User As Users = Nothing
  Public ReadOnly Property User() As Users
    Get
      If _User Is Nothing AndAlso _user_id > 0 Then
        _User = New Users(_user_id)
      End If
      Return _User
    End Get
  End Property

  Public Sub New()
    MyBase.New()
  End Sub

  Public Sub New(ByVal id As Guid)
    MyBase.New()
    _id = id
    Load()
  End Sub

  Public Sub New(ByVal id As String)
    MyBase.New()
    _id = New Guid(id)
    Load()
  End Sub

End Class