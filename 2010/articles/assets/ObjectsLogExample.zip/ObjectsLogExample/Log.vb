﻿Imports System.Data.SqlClient

Public Class Log

  Private _Cmd As New SqlCommand()

  Private _ObjectType As String = ""
  Private _ObjectId As String = ""
  Private _Counter As Integer = 0

  Public Sub New(ByVal objectType As String, ByVal objectId As String)
    _ObjectId = objectId
    _ObjectType = objectType
  End Sub

  Public Sub Add(ByVal field As String, ByVal value As String)
    If Not String.IsNullOrEmpty(_Cmd.CommandText) Then _Cmd.CommandText &= vbCrLf
    _Cmd.CommandText &= String.Format("INSERT INTO [log] ([object], [object_id], [field], [value], [date]) " & _
                        "VALUES (@obj, @obj_id, @field{0}, @value{0}, getDate());", _
                        _Counter)
    If Not _Cmd.Parameters.Contains("@obj") Then _Cmd.Parameters.Add("@obj", SqlDbType.VarChar).Value = _ObjectType
    If Not _Cmd.Parameters.Contains("@obj_id") Then _Cmd.Parameters.Add("@obj_id", SqlDbType.VarChar).Value = _ObjectId
    _Cmd.Parameters.Add(String.Format("@field{0}", _Counter), SqlDbType.VarChar).Value = field
    _Cmd.Parameters.Add(String.Format("@value{0}", _Counter), SqlDbType.VarChar).Value = value
    _Counter += 1
  End Sub

  Public Sub Flush()
    If String.IsNullOrEmpty(_Cmd.CommandText) Then Return
    Using myConn As New SqlConnection(_ConnectionString)
      myConn.Open()
      _Cmd.Connection = myConn
      _Cmd.ExecuteNonQuery()
    End Using
  End Sub

End Class