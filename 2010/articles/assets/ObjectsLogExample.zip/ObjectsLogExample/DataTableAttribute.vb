﻿Public Class DataTableAttribute
  Inherits Attribute

  Private _TableName As String = String.Empty

  Public ReadOnly Property TableName As String
    Get
      Return _TableName
    End Get
  End Property

  Public Sub New(ByVal tableName As String)
    _TableName = tableName
  End Sub

End Class