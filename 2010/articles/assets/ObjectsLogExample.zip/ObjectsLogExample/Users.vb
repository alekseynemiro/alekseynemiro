﻿<DataTableAttribute("users")> _
Public Class Users
  Inherits DataObject

  Private _id As Integer = 0
  Private _first_name As String = String.Empty
  Private _last_name As String = String.Empty
  Private _sex As String = String.Empty
  Private _age As Integer = 0

  <DataColumnAttribute("id", SqlDbType.Int, True, False)> _
  Public Property id() As Integer
    Get
      Return _id
    End Get
    Set(ByVal value As Integer)
      _id = value
    End Set
  End Property

  <DataColumnAttribute("first_name", SqlDbType.NVarChar, False, True)> _
  Public Property first_name() As String
    Get
      Return _first_name
    End Get
    Set(ByVal value As String)
      _first_name = value
    End Set
  End Property

  <DataColumnAttribute("last_name", SqlDbType.NVarChar, False, True)> _
  Public Property last_name() As String
    Get
      Return _last_name
    End Get
    Set(ByVal value As String)
      _last_name = value
    End Set
  End Property

  <DataColumnAttribute("sex", SqlDbType.NVarChar, False, True)> _
  Public Property sex() As String
    Get
      Return _sex
    End Get
    Set(ByVal value As String)
      _sex = value
    End Set
  End Property

  <DataColumnAttribute("age", SqlDbType.Int, False, True)> _
  Public Property age() As Integer
    Get
      Return _age
    End Get
    Set(ByVal value As Integer)
      _age = value
    End Set
  End Property

  Public Sub New()
    MyBase.New()
  End Sub

  Public Sub New(ByVal id As Integer)
    MyBase.New()
    _id = id
    Load()
  End Sub

End Class