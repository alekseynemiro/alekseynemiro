﻿Imports System.Reflection
Imports System.Data.SqlClient

Public MustInherit Class DataObject

  Private _TableName As String = ""
  Private _PrimaryProperty As PropertyInfo = Nothing
  Private _OriginalValues As New Dictionary(Of String, Object)

  Public Sub New()
    _TableName = CType(Me.GetType().GetCustomAttributes(GetType(DataTableAttribute), False)(0), DataTableAttribute).TableName

    For Each p As PropertyInfo In Me.GetType().GetProperties()
      Dim atr As DataColumnAttribute = GetColumnAttribute(p)
      If atr IsNot Nothing AndAlso atr.PrimaryKey Then
        _PrimaryProperty = p
        Exit For
      End If
    Next
  End Sub

  Public Sub Load()
    Using myConn As New SqlConnection(_ConnectionString)
      myConn.Open()

      'получаем атрибуты PrimaryKey
      Dim pk As DataColumnAttribute = GetColumnAttribute(_PrimaryProperty)

      'формируем SQL-запрос на получение данных
      Dim myCmd As New SqlCommand(String.Format("SELECT * FROM [{0}] WHERE [{1}] = @{1}", _TableName, pk.ColumnName), myConn)
      myCmd.Parameters.Add("@" & pk.ColumnName, pk.SqlDataType).Value = _PrimaryProperty.GetValue(Me, Nothing)
      'выполняем запрос
      Dim DR As SqlDataReader = myCmd.ExecuteReader()
      If Not DR.Read Then
        If pk.SqlDataType = SqlDbType.UniqueIdentifier Then
          _PrimaryProperty.SetValue(Me, Guid.Empty, Nothing)
        Else
          _PrimaryProperty.SetValue(Me, 0, Nothing)
        End If
        Return ' Throw New Exception("Ошибка. Данные не найдены.")
      End If
      'листаем все свойства объекта
      For Each p As PropertyInfo In Me.GetType().GetProperties()
        Dim atr As DataColumnAttribute = GetColumnAttribute(p)
        If atr IsNot Nothing Then
          'передаем данные в свойства текущего объекта
          p.SetValue(Me, DR.Item(atr.ColumnName), Nothing)
          'запоминаем оригинальное значение в коллекцию
          _OriginalValues.Add(p.Name, DR.Item(atr.ColumnName))
        End If
      Next
    End Using
  End Sub

  Public Sub Save()
    Using myConn As New SqlConnection(_ConnectionString)
      myConn.Open()

      'получаем атрибуты PrimaryKey
      Dim pk As Object = _PrimaryProperty.GetValue(Me, Nothing)
      Dim pkAtr As DataColumnAttribute = GetColumnAttribute(_PrimaryProperty)

      'определяем, это новые данные и их нужно создать,
      'или данные уже есть в БД и нужно сохранить изменения
      Dim isNewData As Boolean = False
      If pkAtr.SqlDataType = SqlDbType.UniqueIdentifier Then
        'PrimaryKey - это Guid,
        'смотрим, если его нет, или он равен Empry, значит это новые данные
        isNewData = pk Is Nothing OrElse CType(pk, Guid) = Guid.Empty
      Else
        'скорей всего PrimaryKey - числовой счетчик, проверяем на ноль
        'Если ноль, то это новые данные, если больше нуля - то данные уже есть в БД
        isNewData = pk <= 0
        'вообще, PrimaryKey может быть и строковым и датой, это исключением можно и нужно учесть,
        'однако в данном примере я этого делать не буду, т.к. такие PrimeryKey бывают редко
      End If

      'формируем SQL-запрос на получение данных
      Dim myCmd As New SqlCommand() With {.Connection = myConn}
      Dim parUpdate As String = "", parInsertFields As String = "", parInsertValues As String = ""

      'если это не новые данные, то инициализируем журнал
      Dim myLog As Log = Nothing
      If Not isNewData Then myLog = New Log(Me.GetType().ToString(), pk.ToString())

      'перебираем свойства и формируем данные для SQL-запроса, а также для журнала отчета
      For Each p As PropertyInfo In Me.GetType().GetProperties()
        Dim atr As DataColumnAttribute = GetColumnAttribute(p)
        If atr IsNot Nothing Then
          If Not isNewData Then
            'нужно сохранить данные
            If Not atr.PrimaryKey Then
              If Not String.IsNullOrEmpty(parUpdate) Then parUpdate &= ", "
              parUpdate &= String.Format("[{0}] = @{0}", atr.ColumnName)
            End If
            myCmd.Parameters.Add("@" & atr.ColumnName, atr.SqlDataType).Value = p.GetValue(Me, Nothing)
            'если свойство нужно записывать в журнал, и оно изменились
            If atr.Log AndAlso DataIsChanged(p) Then
              'добавляем задание на запись
              myLog.Add(p.Name, _OriginalValues(atr.ColumnName).ToString())
            End If
          Else
            'нужно добавить новые данные
            If Not atr.PrimaryKey Then
              'подразумевается, что PrimaryKey - это числовой счетчик, его указывать не нужно
              If Not String.IsNullOrEmpty(parInsertFields) Then parInsertFields &= ", "
              If Not String.IsNullOrEmpty(parInsertValues) Then parInsertValues &= ", "
              parInsertFields &= String.Format("[{0}]", atr.ColumnName)
              parInsertValues &= "@" & atr.ColumnName
              myCmd.Parameters.Add("@" & atr.ColumnName, atr.SqlDataType).Value = p.GetValue(Me, Nothing)
            ElseIf atr.PrimaryKey AndAlso atr.SqlDataType = SqlDbType.UniqueIdentifier Then
              'это PrimaryKey, но он имеет тип Guid
              'мы будем генерировать его на строне .NET (а не использовать SQL-функцию NEWID), 
              'чтобы знать, какой идентификатор был создан
              If Not String.IsNullOrEmpty(parInsertFields) Then parInsertFields &= ", "
              If Not String.IsNullOrEmpty(parInsertValues) Then parInsertValues &= ", "
              parInsertFields &= String.Format("[{0}]", atr.ColumnName)
              parInsertValues &= "@" & atr.ColumnName
              myCmd.Parameters.Add("@" & atr.ColumnName, atr.SqlDataType).Value = Guid.NewGuid()
            End If
          End If
        End If
      Next

      If isNewData Then
        'нужно добавить новые данные
        myCmd.CommandText = String.Format("INSERT INTO [{0}] ({1}) VALUES ({2});SELECT SCOPE_IDENTITY();", _TableName, parInsertFields, parInsertValues)
        'запоминаем новый идентификатор
        Dim newId As Object = Nothing
        If pkAtr.SqlDataType = SqlDbType.UniqueIdentifier Then
          myCmd.ExecuteNonQuery()
          newId = CType(myCmd.Parameters("@" & pkAtr.ColumnName).Value, Guid)
        ElseIf pkAtr.SqlDataType = SqlDbType.Int Then
          newId = CType(myCmd.ExecuteScalar(), Integer)
        ElseIf pkAtr.SqlDataType = SqlDbType.BigInt Then
          newId = CType(myCmd.ExecuteScalar(), Long)
          'список (ElseIf) можно продолжить :-)
        End If
        'передаем в свойство текущего объекта PrimeryKey новый идентификатор
        _PrimaryProperty.SetValue(Me, newId, Nothing)
      Else
        'нужно сохранить данные
        myCmd.CommandText = String.Format("UPDATE [{0}] SET {1} WHERE [{2}] = @{2}", _TableName, parUpdate, pkAtr.ColumnName)
        myCmd.ExecuteNonQuery()
        'запись данных в журнал
        myLog.Flush()
      End If
    End Using
  End Sub

  Public Sub Delete()
    Using myConn As New SqlConnection(_ConnectionString)
      myConn.Open()

      'получаем атрибуты PrimaryKey
      Dim pk As DataColumnAttribute = GetColumnAttribute(_PrimaryProperty)

      'формируем SQL-запрос
      Dim myCmd As New SqlCommand(String.Format("DELETE FROM [{0}] WHERE [{1}] = @{1}", _TableName, pk.ColumnName), myConn)
      myCmd.Parameters.Add("@" & pk.ColumnName, pk.SqlDataType).Value = _PrimaryProperty.GetValue(Me, Nothing)
      'выполняем запрос
      myCmd.ExecuteNonQuery()
    End Using
  End Sub

  ''' <summary>
  ''' Хелпер-функция, ищет и возвращает атрибут DataColumnAttribute в указанном свойстве 
  ''' </summary>
  ''' <param name="p">Свойство, из которого нужно извлечь атрибут DataColumnAttribute</param>
  Private Function GetColumnAttribute(ByVal p As PropertyInfo) As DataColumnAttribute
    Dim atr() As Object = p.GetCustomAttributes(GetType(DataColumnAttribute), False)
    If atr Is Nothing OrElse atr.Length <= 0 Then Return Nothing
    Return CType(atr(0), DataColumnAttribute)
  End Function

  ''' <summary>
  ''' Хелпер-функция, возвращает True, если данные в указанном свойстве изменились
  ''' </summary>
  ''' <param name="p">Свойство для проверки изменений</param>
  Private Function DataIsChanged(ByVal p As PropertyInfo) As Boolean
    'если в памяти нет значения для указанного свойства, возвращаем False - данные не менялись
    If Not _OriginalValues.ContainsKey(p.Name) Then Return False
    Dim v As Object = p.GetValue(Me, Nothing)
    'некоторые типы данных нельзя сравнивать оператором =, используем оператор Is - инвертно IsNot
    If v.GetType().BaseType() IsNot Nothing AndAlso v.GetType().BaseType() Is GetType(Array) Then Return v IsNot _OriginalValues(p.Name)
    If v.GetType() Is GetType(Guid) Then Return v IsNot _OriginalValues(p.Name)
    'остальные можно сранивать оператором =
    Return Not _OriginalValues(p.Name) = v
  End Function

End Class